"""Demo senza kernel ne' DEM reali: usa il fallback analitico e un terreno SINTETICO.

I numeri di questa demo mostrano che la pipeline funziona, NON descrivono terreno lunare reale.
Uso (dalla cartella del progetto):  python -m examples.demo
"""
import json
from datetime import datetime, timezone

from grazinglink.compare import compare, shifted
from grazinglink.ephemeris import build_ephemeris
from grazinglink.mission import MissionEngine
from grazinglink.models import Antenna, MissionScenario
from grazinglink.terrain import Dem, DemCatalog, MemoryDemSource, latlon_to_xy_south, xy_to_latlon_south


def fake_terrain(x, y):
    """Un massiccio a nord del sito (lon 0): crea ombra e occultamento della Terra."""
    lat, lon = xy_to_latlon_south(x, y)
    ridge = 500.0 * (abs(lon) < 25) * ((lat > -85.4) & (lat < -85.3))
    return ridge


centre = latlon_to_xy_south(-85.35, 20.0)      # circa a meta strada tra i due siti della demo
dem = Dem.from_function(fake_terrain, half_size_m=60_000, res_m=100, dem_id="SYNTHETIC-demo", center_xy=centre)
catalog = DemCatalog([MemoryDemSource(dem)])
engine = MissionEngine(build_ephemeris(), catalog)

base = dict(id="A", name="Demo site", latitude=-85.5, longitude=0.0, observer_height_m=2.0,
            start_time=datetime(2027, 4, 7, tzinfo=timezone.utc), duration_hours=120, time_step_minutes=15,
            antenna=Antenna())
A = MissionScenario(**base)
B = MissionScenario(**{**base, "id": "B", "latitude": -85.2, "longitude": 40.0})
res = [engine.run(A), engine.run(B)]
print(json.dumps(res[0].summary, indent=2))
print(json.dumps(compare(res)["metrics"][:4], indent=2))
print(json.dumps(engine.countdown(A), indent=2))
print(json.dumps(res[0].provenance["warnings"], indent=2))
