"""Horizon Engine.

Per ogni azimut campiona il terreno lungo il cerchio massimo uscente dal sito. Per ogni campione
calcola l'angolo apparente nel piano (centro Luna, osservatore, campione):

    osservatore a (0, ro),  campione a (rs*sin(t), rs*cos(t)),  t = d / R
    elevazione = atan2(rs*cos(t) - ro, rs*sin(t))

La curvatura lunare e' quindi inclusa per costruzione (nessuna correzione empirica), e anche la
"caduta" dell'orizzonte su terreno piatto emerge da sola: -acos(R/(R+h)).
Il profilo e' il massimo angolo per azimut. Senza DEM resta la sola sfera.

Limiti dichiarati: spaziatura pari alla risoluzione del DEM nei primi 2 km, poi allargata se serve per
restare sotto max_steps;
campioni oltre il bordo del DEM trattati come sfera nuda (segnalati in dem_limited).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .config import MOON_RADIUS_M
from .terrain import Dem, DemStack, latlon_to_xy_south


@dataclass
class HorizonProfile:
    az_deg: np.ndarray            # (n,) 0..360 (esclusa)
    elev_deg: np.ndarray          # (n,) elevazione dell'orizzonte
    range_m: np.ndarray           # (n,) distanza (retta) dell'ostacolo dominante
    dem_limited: np.ndarray       # (n,) bool: il raggio ha incontrato celle senza dato
    sphere_dip_deg: float         # orizzonte della sola sfera (negativo)
    site_elevation_m: float
    max_range_m: float
    dem_id: str | None
    dem_res_m: float | None

    def at(self, az_deg) -> np.ndarray:
        """Elevazione dell'orizzonte a un azimut qualsiasi (interpolazione periodica)."""
        return np.interp(np.asarray(az_deg, float) % 360.0, self.az_deg, self.elev_deg, period=360.0)

    def to_dict(self, decimate: int = 1) -> dict:
        s = slice(None, None, max(1, decimate))
        return {"az_deg": np.round(self.az_deg[s], 3).tolist(), "elev_deg": np.round(self.elev_deg[s], 4).tolist(),
                "sphere_dip_deg": round(self.sphere_dip_deg, 4), "site_elevation_m": round(self.site_elevation_m, 2),
                "max_range_km": self.max_range_m / 1000.0, "dem_id": self.dem_id, "dem_resolution_m": self.dem_res_m,
                "dem_limited_fraction": float(self.dem_limited.mean())}


@dataclass
class RayBundle:
    angle_rad: np.ndarray         # (n_az, n_d)
    range_m: np.ndarray           # (n_az, n_d) distanza retta osservatore-campione
    had_nodata: np.ndarray        # (n_az,)


class HorizonEngine:
    def __init__(self, radius_m: float = MOON_RADIUS_M, max_steps: int = 4000, flat_step_m: float = 250.0,
                 near_zone_m: float = 2000.0):
        self.R, self.max_steps, self.flat_step_m, self.near_zone_m = radius_m, max_steps, flat_step_m, near_zone_m

    def _distances(self, dem, max_range_m: float) -> np.ndarray:
        """Passo pari alla risoluzione (del DEM piu' fine) nella zona vicina, piu' largo se serve oltre."""
        fine = dem.res_m if dem is not None else self.flat_step_m
        n_near = int(min(self.near_zone_m, max_range_m) // fine)
        near = fine * np.arange(1, n_near + 1)
        start = near[-1] if n_near else 0.0
        if start >= max_range_m - fine / 2:
            return near
        far_step = max(fine, (max_range_m - start) / max(self.max_steps - n_near, 1))
        return np.concatenate([near, start + far_step * np.arange(1, int((max_range_m - start) // far_step) + 1)])

    def site_elevation(self, dem: Dem | None, lat_deg: float, lon_deg: float) -> float:
        if dem is None:
            return 0.0
        x, y = latlon_to_xy_south(np.array([lat_deg]), np.array([lon_deg]))
        z = dem.sample(x, y)[0]
        return 0.0 if np.isnan(z) else float(z)

    def rays(self, dem: Dem | DemStack | None, lat_deg: float, lon_deg: float, observer_height_m: float,
             az_deg, max_range_m: float) -> RayBundle:
        R = self.R
        az = np.radians(np.atleast_1d(np.asarray(az_deg, float)))[:, None]
        d = self._distances(dem, max_range_m)[None, :]
        theta = d / R
        lat1, lon1 = np.radians(lat_deg), np.radians(lon_deg)
        sin_lat2 = np.sin(lat1) * np.cos(theta) + np.cos(lat1) * np.sin(theta) * np.cos(az)
        lat2 = np.arcsin(np.clip(sin_lat2, -1, 1))
        lon2 = lon1 + np.arctan2(np.sin(az) * np.sin(theta) * np.cos(lat1), np.cos(theta) - np.sin(lat1) * sin_lat2)
        if dem is not None:
            z = dem.sample(*latlon_to_xy_south(np.degrees(lat2), np.degrees(lon2)))
        else:
            z = np.zeros_like(lat2)
        nodata = np.isnan(z)
        z = np.where(nodata, 0.0, z)
        ro = R + self.site_elevation(dem, lat_deg, lon_deg) + observer_height_m
        rs = R + z
        ex, ey = rs * np.sin(theta), rs * np.cos(theta) - ro
        return RayBundle(np.arctan2(ey, ex), np.hypot(ex, ey), nodata.any(axis=1))

    def profile(self, dem: Dem | DemStack | None, lat_deg: float, lon_deg: float, observer_height_m: float,
                n_az: int = 720, max_range_m: float = 60_000.0) -> HorizonProfile:
        az = np.arange(n_az) * (360.0 / n_az)
        elev, rng, lim = np.empty(n_az), np.empty(n_az), np.empty(n_az, bool)
        for i in range(0, n_az, 90):          # a blocchi per contenere la memoria
            b = self.rays(dem, lat_deg, lon_deg, observer_height_m, az[i:i + 90], max_range_m)
            k = np.argmax(b.angle_rad, axis=1)
            rows = np.arange(k.size)
            elev[i:i + 90] = np.degrees(b.angle_rad[rows, k])
            rng[i:i + 90] = b.range_m[rows, k]
            lim[i:i + 90] = b.had_nodata
        z_site = self.site_elevation(dem, lat_deg, lon_deg)
        dip = -np.degrees(np.arccos((self.R + z_site) / (self.R + z_site + observer_height_m)))
        return HorizonProfile(az, elev, rng, lim, float(dip), z_site, max_range_m,
                              dem.dem_id if dem is not None else None, dem.res_m if dem is not None else None)
