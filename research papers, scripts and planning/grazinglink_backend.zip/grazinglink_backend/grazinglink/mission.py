"""MissionEngine: collega effemeridi, orizzonte, illuminazione, visibilita' della Terra e RF.

Il frontend riceve solo risultati e provenienza: nessuna logica scientifica fuori da qui.
Le tre condizioni NON sono sinonimi e restano separate in ogni output:
  sunlit         -> il disco solare e' sopra l'orizzonte locale (frazione visibile > soglia)
  earth_visible  -> il disco terrestre e' sopra l'orizzonte locale (frazione visibile > soglia)
  rf_ok          -> il link budget (con diffrazione) supera la soglia di margine
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

import numpy as np

from . import config as cfg
from .ephemeris import BaseEphemeris
from .horizon import HorizonEngine, HorizonProfile
from .models import MissionScenario
from .rf import classify_path, fresnel_nu, knife_edge_loss_db, link_budget
from .terrain import Dem, DemCatalog, DemStack
from .visibility import disc_visible_fraction, enu_to_azel, solar_power_w
from .windows import Window, complement, extract_windows, humanize, next_edge

_trapz = getattr(np, "trapezoid", None) or np.trapz
_CHUNK = 200            # raggi Terra valutati insieme (limita la memoria)


@dataclass
class _Context:
    scenario: MissionScenario
    dem: Dem | DemStack | None
    horizon: HorizonProfile
    max_range_m: float


def _iso(t0: datetime, s: float) -> str:
    return (t0 + timedelta(seconds=float(s))).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _lst(a: np.ndarray, nd: int = 3) -> list:
    return [None if not np.isfinite(v) else round(float(v), nd) for v in np.asarray(a, float)]


def _longest_run(mask: np.ndarray) -> int:
    """Lunghezza (in campioni) della piu' lunga sequenza di True."""
    if not mask.any():
        return 0
    d = np.diff(np.concatenate(([0], mask.astype(np.int8), [0])))
    return int((np.flatnonzero(d == -1) - np.flatnonzero(d == 1)).max())


@dataclass
class ScenarioResult:
    scenario: MissionScenario
    t_s: np.ndarray
    samples: dict[str, np.ndarray]
    horizon: HorizonProfile
    windows: dict[str, list[Window]]
    gaps: dict[str, list[Window]]
    summary: dict
    provenance: dict

    def _win(self, ws: list[Window]) -> list[dict]:
        t0 = self.scenario.start_time
        return [{"start": _iso(t0, w.start_s), "end": _iso(t0, w.end_s), "start_s": round(w.start_s, 1),
                 "end_s": round(w.end_s, 1), "duration_h": round(w.duration_s / 3600, 4),
                 "opened_by": w.opened_by, "closed_by": w.closed_by} for w in ws]

    def to_dict(self, decimate: int = 1, include_series: bool = True) -> dict:
        out = {"scenario": self.scenario.model_dump(mode="json", by_alias=True),
               "summary": self.summary, "provenance": self.provenance,
               "windows": {k: self._win(v) for k, v in self.windows.items()},
               "gaps": {k: self._win(v) for k, v in self.gaps.items()},
               "horizon": self.horizon.to_dict(decimate=max(1, self.scenario.n_azimuths // 360))}
        if include_series:
            s = slice(None, None, max(1, int(decimate)))
            t0 = self.scenario.start_time
            series = {"time": [_iso(t0, x) for x in self.t_s[s]], "t_hours": _lst(self.t_s[s] / 3600.0, 4)}
            for k, v in self.samples.items():
                v = v[s]
                series[k] = v.tolist() if v.dtype.kind in "bUO" else _lst(v, 4 if "frac" in k else 3)
            out["series"] = series
        return out


class MissionEngine:
    def __init__(self, ephemeris: BaseEphemeris, dem_catalog: DemCatalog | None = None,
                 horizon_engine: HorizonEngine | None = None) -> None:
        self.eph = ephemeris
        self.catalog = dem_catalog or DemCatalog()
        self.hz = horizon_engine or HorizonEngine()
        self._ctx_cache: dict = {}

    # ------------------------------------------------------------------ contesto (orizzonte)
    def context(self, sc: MissionScenario) -> _Context:
        rng_m = sc.horizon_range_km * 1000.0
        key = (round(sc.latitude, 5), round(sc.longitude, 5), sc.observer_height_m, sc.n_azimuths, rng_m)
        if key not in self._ctx_cache:
            if len(self._ctx_cache) > 64:
                self._ctx_cache.pop(next(iter(self._ctx_cache)))
            dem = self.catalog.load(sc.latitude, sc.longitude, rng_m)
            prof = self.hz.profile(dem, sc.latitude, sc.longitude, sc.observer_height_m, sc.n_azimuths, rng_m)
            self._ctx_cache[key] = _Context(sc, dem, prof, rng_m)
        c = self._ctx_cache[key]
        return _Context(sc, c.dem, c.horizon, c.max_range_m)

    # ------------------------------------------------------------------ valutazione a istanti arbitrari
    def _evaluate(self, ctx: _Context, t_s: np.ndarray, domains: set[str]) -> dict[str, np.ndarray]:
        sc, prof = ctx.scenario, ctx.horizon
        t_s = np.atleast_1d(np.asarray(t_s, float))
        sky = self.eph.sky(sc.start_time, t_s, sc.latitude, sc.longitude, sc.observer_height_m)
        sun_az, sun_el = enu_to_azel(sky.sun_enu)
        ea_az, ea_el = enu_to_azel(sky.earth_enu)
        dip = prof.sphere_dip_deg
        out: dict[str, np.ndarray] = {
            "sun_az_deg": sun_az, "sun_el_deg": sun_el, "horizon_at_sun_deg": prof.at(sun_az),
            "earth_az_deg": ea_az, "earth_el_deg": ea_el, "horizon_at_earth_deg": prof.at(ea_az),
            "earth_distance_km": sky.earth_dist_km}

        if "sun" in domains:
            frac = disc_visible_fraction(prof, sun_az, sun_el, sky.sun_radius_deg)
            lit = frac > sc.sun_min_visible_fraction
            out["sun_visible_fraction"] = frac
            out["sunlit"] = lit
            out["sunlit_reason"] = np.where(lit, "ok", np.where(sun_el > dip, "terrain_occultation",
                                                                  "below_lunar_horizon"))
            out["solar_power_w"] = solar_power_w(sc.solar_panel, sky.sun_enu, sky.sun_dist_km, frac)

        if "earth" in domains:
            frac = disc_visible_fraction(prof, ea_az, ea_el, sky.earth_radius_deg)
            vis = frac > sc.earth_min_visible_fraction
            out["earth_visible_fraction"] = frac
            out["earth_visible"] = vis
            out["earth_visible_reason"] = np.where(vis, "ok", np.where(ea_el > dip, "terrain_occultation",
                                                                         "below_lunar_horizon"))

        if "rf" in domains and sc.antenna is not None:
            ant = sc.antenna
            nu = np.empty(t_s.size)
            el_rad = np.radians(ea_el)
            for i in range(0, t_s.size, _CHUNK):      # ostacolo dominante = massimo nu lungo il raggio
                b = self.hz.rays(ctx.dem, sc.latitude, sc.longitude, sc.observer_height_m,
                                 ea_az[i:i + _CHUNK], ctx.max_range_m)
                clearance = b.range_m * np.sin(b.angle_rad - el_rad[i:i + _CHUNK, None])
                nu[i:i + _CHUNK] = fresnel_nu(clearance, b.range_m, ant.frequency_hz).max(axis=1)
            diff = knife_edge_loss_db(nu)
            lb = link_budget(ant, sky.earth_dist_km * 1000.0, diff, sc.rf_threshold_db)
            unavailable = nu > cfg.DIFFRACTION_NU_LIMIT
            state = np.where(unavailable, "unavailable",
                             np.where(lb.margin_db >= sc.rf_threshold_db, "above_threshold", "below_threshold"))
            ok = state == "above_threshold"
            out.update({
                "fresnel_nu": nu, "path_condition": classify_path(nu), "fspl_db": lb.fspl_db,
                "diffraction_loss_db": diff, "cn0_dbhz": lb.cn0_dbhz, "ebn0_db": lb.ebn0_db,
                "link_margin_db": np.where(unavailable, np.nan, lb.margin_db),
                "max_bitrate_bps": np.where(unavailable, 0.0, lb.max_bitrate_bps),
                "rf_state": state, "rf_ok": ok,
                "rf_reason": np.where(ok, "ok", np.where(unavailable, "shadowed_beyond_model",
                                                         "margin_below_threshold"))})
        return out

    # ------------------------------------------------------------------ simulazione completa
    def run(self, sc: MissionScenario, refine: bool = True) -> ScenarioResult:
        ctx = self.context(sc)
        dur_s, step_s = sc.duration_hours * 3600.0, sc.time_step_minutes * 60.0
        t_s = np.append(np.arange(0.0, dur_s, step_s), dur_s)
        domains = {"sun", "earth"} | ({"rf"} if sc.antenna else set())
        S = self._evaluate(ctx, t_s, domains)

        specs = [("sun", "sunlit", "sunlit_reason"), ("earth", "earth_visible", "earth_visible_reason")]
        if sc.antenna:
            specs.append(("rf", "rf_ok", "rf_reason"))
        windows, gaps = {}, {}
        for dom, key, rkey in specs:
            pred = (lambda tt, d=dom, k=key: self._evaluate(ctx, tt, {d})[k]) if refine else None
            windows[dom] = extract_windows(t_s, S[key], S[rkey], pred)
            gaps[dom] = complement(t_s, S[key], pred)
        return ScenarioResult(sc, t_s, S, ctx.horizon, windows, gaps,
                              self._summary(sc, t_s, S, windows, gaps), self._provenance(ctx, sc))

    # ------------------------------------------------------------------ riepilogo
    @staticmethod
    def _summary(sc, t_s, S, windows, gaps) -> dict:
        total = float(t_s[-1] - t_s[0])
        pct = lambda ws: round(100.0 * sum(w.duration_s for w in ws) / total, 2)  # noqa: E731
        longest = lambda ws: (round(max(w.duration_s for w in ws) / 3600.0, 3) if ws else 0.0)  # noqa: E731
        touches = lambda ws: bool(ws) and any(  # noqa: E731
            w.duration_s == max(x.duration_s for x in ws) and (w.opened_by == "start_of_simulation"
                                                                or w.closed_by == "end_of_simulation") for w in ws)
        sm: dict = {
            "duration_h": sc.duration_hours,
            "sunlit_percent": pct(windows["sun"]), "n_sun_windows": len(windows["sun"]),
            "longest_dark_h": longest(gaps["sun"]), "longest_dark_truncated": touches(gaps["sun"]),
            "sun_elevation_max_deg": round(float(S["sun_el_deg"].max()), 3),
            "mean_solar_power_w": round(float(_trapz(S["solar_power_w"], t_s) / total), 3),
            "solar_energy_wh": round(float(_trapz(S["solar_power_w"], t_s) / 3600.0), 2),
            "earth_visible_percent": pct(windows["earth"]), "n_earth_windows": len(windows["earth"]),
            "longest_earth_blackout_h": longest(gaps["earth"]),
            "longest_earth_blackout_truncated": touches(gaps["earth"]),
            "earth_elevation_min_deg": round(float(S["earth_el_deg"].min()), 3),
            "earth_elevation_max_deg": round(float(S["earth_el_deg"].max()), 3),
            "sun_and_earth_percent": round(100.0 * float(np.mean(S["sunlit"] & S["earth_visible"])), 2)}
        if sc.antenna:
            ok = S["rf_ok"]
            in_win = lambda a: a[ok]  # noqa: E731
            sm.update({
                "rf_available_percent": pct(windows["rf"]), "n_rf_windows": len(windows["rf"]),
                "rf_longest_outage_h": longest(gaps["rf"]), "rf_longest_outage_truncated": touches(gaps["rf"]),
                "rf_margin_mean_db_in_windows": round(float(in_win(S["link_margin_db"]).mean()), 2) if ok.any() else None,
                "rf_margin_min_db_in_windows": round(float(in_win(S["link_margin_db"]).min()), 2) if ok.any() else None,
                "rf_median_max_bitrate_bps_in_windows": round(float(np.median(in_win(S["max_bitrate_bps"]))), 0) if ok.any() else None,
                "rf_relying_on_diffraction_percent": round(
                    100.0 * float(np.mean(ok & np.isin(S["path_condition"], ["fresnel_zone_obstructed", "diffracted"]))), 2),
                "sun_and_rf_percent": round(100.0 * float(np.mean(S["sunlit"] & ok)), 2)})
        return sm

    def _provenance(self, ctx: _Context, sc: MissionScenario) -> dict:
        prof = ctx.horizon
        warnings = list(self.eph.warnings)
        if ctx.dem is None:
            warnings.append("No DEM covers this site: horizon = lunar curvature only (no terrain). "
                            "Sun/Earth windows are optimistic.")
        elif prof.dem_limited.mean() > 0:
            warnings.append(f"DEM coverage ends inside the {sc.horizon_range_km:g} km horizon range for "
                            f"{100 * prof.dem_limited.mean():.0f}% of azimuths: terrain beyond is treated as flat sphere.")
        if sc.antenna:
            warnings.append("RF parameters are illustrative; single knife-edge diffraction (ITU-R P.526) on the "
                            "terrain profile towards Earth; no multipath, no rounded-ridge model, no relay; "
                            "not validated against flight data.")
        warnings.append("Sun and Earth treated as uniform discs; no refraction (airless Moon); "
                        "illumination is geometric (no light scattering or secondary illumination).")
        return {"ephemeris": self.eph.describe(),
                "dem": None if ctx.dem is None else {
                    "id": ctx.dem.dem_id, "resolution_m": ctx.dem.res_m,
                    "layers": [{"id": d.dem_id, "resolution_m": d.res_m} for d in getattr(ctx.dem, "layers", [ctx.dem])],
                    "site_elevation_m": round(prof.site_elevation_m, 2)},
                "horizon": {"range_km": sc.horizon_range_km, "n_azimuths": sc.n_azimuths,
                            "sphere_radius_m": cfg.MOON_RADIUS_M},
                "time_step_minutes": sc.time_step_minutes, "window_edges_refined_by_bisection": True,
                "warnings": warnings}

    # ------------------------------------------------------------------ conto alla rovescia
    def countdown(self, sc: MissionScenario, at: datetime | None = None, max_days: float = 35.0,
                  step_min: float = 30.0) -> dict:
        """Tempo al prossimo tramonto/alba e Earthset/Earthrise a partire da 'at'."""
        at = at or sc.start_time
        base = sc.model_copy(update={"start_time": at.astimezone(timezone.utc), "duration_hours": max_days * 24.0,
                                     "time_step_minutes": step_min, "antenna": None})
        ctx = self.context(base)
        t_s = np.append(np.arange(0.0, base.duration_hours * 3600.0, step_min * 60.0), base.duration_hours * 3600.0)
        S = self._evaluate(ctx, t_s, {"sun", "earth"})
        res = {"at": _iso(base.start_time, 0.0), "search_horizon_days": max_days}
        for dom, key, up, down in (("sun", "sunlit", "sunrise", "sunset"), ("earth", "earth_visible", "earthrise", "earthset")):
            pred = lambda tt, d=dom, k=key: self._evaluate(ctx, tt, {d})[k]  # noqa: E731
            edge = next_edge(t_s, S[key], pred)
            state = bool(S[key][0])
            res[dom] = {"state": ("sunlit" if state else "dark") if dom == "sun" else ("visible" if state else "hidden"),
                        "next_event": (down if state else up) if edge is not None else None,
                        "in_seconds": None if edge is None else round(edge, 1),
                        "in_human": None if edge is None else humanize(edge),
                        "at": None if edge is None else _iso(base.start_time, edge),
                        "note": None if edge is not None else f"no change within {max_days:g} days"}
        return res

    # ------------------------------------------------------------------ scansione di molti giorni (heatmap)
    def sweep(self, sc: MissionScenario, n_days: int, stride_days: float = 1.0, window_hours: float = 24.0,
              step_min: float = 30.0) -> dict:
        """% di luce e di Terra visibile per finestre di window_hours che partono ogni stride_days."""
        per = max(2, int(window_hours * 60.0 / step_min))
        if n_days * per > cfg.MAX_TIME_STEPS:
            raise ValueError(f"{n_days * per} campioni oltre il limite {cfg.MAX_TIME_STEPS}: riduci n_days o aumenta step_min")
        ctx = self.context(sc)
        starts = np.arange(n_days) * stride_days * 86400.0
        offs = (starts[:, None] + np.arange(per)[None, :] * step_min * 60.0).ravel()
        S = self._evaluate(ctx, offs, {"sun", "earth"})
        m = lambda k: S[k].reshape(n_days, per)  # noqa: E731
        return {"site": {"id": sc.id, "latitude": sc.latitude, "longitude": sc.longitude},
                "window_hours": window_hours, "step_minutes": step_min,
                "start": [_iso(sc.start_time, s) for s in starts],
                "sunlit_percent": _lst(100 * m("sunlit").mean(axis=1), 2),
                "earth_visible_percent": _lst(100 * m("earth_visible").mean(axis=1), 2),
                "sun_and_earth_percent": _lst(100 * (m("sunlit") & m("earth_visible")).mean(axis=1), 2)}

    # ------------------------------------------------------------------ finestre di permanenza
    def stay_windows(self, sc: MissionScenario, n_days: int, stay_hours: float = 156.0, stride_hours: float = 6.0,
                     step_min: float = 30.0, continuous_sunlight: bool = True,
                     max_earth_blackout_h: float | None = None,
                     min_earth_visible_percent: float | None = None) -> dict:
        """Per ogni data di arrivo (ogni stride_hours, per n_days) valuta una permanenza di stay_hours.

        Criterio NASA del 2022: siti con luce solare continua per tutta la permanenza (6.5 giorni per
        l'Artemis III originale = 156 h; per altre missioni imposta stay_hours). Si possono aggiungere
        vincoli sul blackout della Terra. Risoluzione: step_min (un'ombra piu' breve del passo puo'
        sfuggire: per decisioni critiche usa passi piu' corti).
        """
        step_s = step_min * 60.0
        stride_steps = max(1, int(round(stride_hours * 3600.0 / step_s)))
        L = int(round(stay_hours * 3600.0 / step_s))
        n_starts = int(n_days * 86400.0 / (stride_steps * step_s)) + 1
        n_samples = (n_starts - 1) * stride_steps + L + 1
        if n_samples > cfg.MAX_TIME_STEPS:
            raise ValueError(f"{n_samples} campioni oltre il limite {cfg.MAX_TIME_STEPS}: aumenta step_min o riduci n_days")
        ctx = self.context(sc)
        S = self._evaluate(ctx, np.arange(n_samples) * step_s, {"sun", "earth"} | ({"rf"} if sc.antenna else set()))
        cols: dict[str, list] = {k: [] for k in ("sunlit_percent", "longest_dark_h", "earth_visible_percent",
                                                 "longest_earth_blackout_h")}
        if sc.antenna:
            cols["rf_available_percent"] = []
        for k in range(n_starts):
            sl = slice(k * stride_steps, k * stride_steps + L + 1)
            sun, ea = S["sunlit"][sl], S["earth_visible"][sl]
            cols["sunlit_percent"].append(100.0 * sun.mean())
            cols["longest_dark_h"].append(_longest_run(~sun) * step_min / 60.0)
            cols["earth_visible_percent"].append(100.0 * ea.mean())
            cols["longest_earth_blackout_h"].append(_longest_run(~ea) * step_min / 60.0)
            if sc.antenna:
                cols["rf_available_percent"].append(100.0 * S["rf_ok"][sl].mean())
        a = {k: np.array(v) for k, v in cols.items()}
        ok = np.ones(n_starts, bool)
        if continuous_sunlight:
            ok &= a["longest_dark_h"] == 0.0
        if max_earth_blackout_h is not None:
            ok &= a["longest_earth_blackout_h"] <= max_earth_blackout_h
        if min_earth_visible_percent is not None:
            ok &= a["earth_visible_percent"] >= min_earth_visible_percent
        edges = np.flatnonzero(np.diff(np.concatenate(([0], ok.astype(np.int8), [0]))))
        ok_ranges = [{"first_start": _iso(sc.start_time, i * stride_steps * step_s),
                      "last_start": _iso(sc.start_time, (j - 1) * stride_steps * step_s), "n_starts": int(j - i)}
                     for i, j in zip(edges[::2], edges[1::2])]
        starts = [_iso(sc.start_time, i * stride_steps * step_s) for i in range(n_starts)]
        return {"site": {"id": sc.id, "latitude": sc.latitude, "longitude": sc.longitude},
                "stay_hours": stay_hours, "stride_hours": stride_steps * step_s / 3600.0, "step_minutes": step_min,
                "criteria": {"continuous_sunlight": continuous_sunlight, "max_earth_blackout_h": max_earth_blackout_h,
                             "min_earth_visible_percent": min_earth_visible_percent},
                "start": starts, "ok": ok.tolist(), **{k: _lst(v, 2) for k, v in a.items()},
                "summary": {"n_starts": n_starts, "n_ok": int(ok.sum()), "ok_percent": round(100.0 * ok.mean(), 1),
                            "ok_start_ranges": ok_ranges},
                "provenance": self._provenance(ctx, sc),
                "note": "start = arrival (touchdown) time; a stay is OK only if the criteria hold for its whole length."}

    def horizon_profile(self, lat: float, lon: float, observer_height_m: float = 2.0, n_az: int = 720,
                        range_km: float = 60.0) -> dict:
        dem = self.catalog.load(lat, lon, range_km * 1000.0)
        prof = self.hz.profile(dem, lat, lon, observer_height_m, n_az, range_km * 1000.0)
        return prof.to_dict(decimate=max(1, n_az // 360))
