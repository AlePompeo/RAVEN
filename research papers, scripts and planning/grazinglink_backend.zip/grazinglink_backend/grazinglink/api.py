"""API REST. Avvio:  uvicorn grazinglink.api:app --reload   (docs interattive su /docs)

I calcoli sono CPU-bound e sincroni: gli endpoint sono `def`, FastAPI li esegue in un thread pool.
"""
from __future__ import annotations

import json
from datetime import datetime

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field

from . import __version__
from . import config as cfg
from .artemis import regions_with_status
from .compare import compare, shifted
from .ephemeris import build_ephemeris
from .mission import MissionEngine
from .models import MissionScenario
from .terrain import DemCatalog


class _Req(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="forbid")


class CompareRequest(_Req):
    scenarios: list[MissionScenario] = Field(min_length=2, max_length=6)
    include_series: bool = False


class CompareShiftRequest(_Req):
    """Stesso sito, date diverse: l'originale piu' una copia per ogni spostamento (in giorni)."""
    scenario: MissionScenario
    shift_days: list[float] = Field(min_length=1, max_length=5)
    include_series: bool = False


class HorizonRequest(_Req):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=360)
    observer_height_m: float = Field(2.0, ge=0, le=100)
    n_azimuths: int = Field(720, ge=72, le=7200)
    range_km: float = Field(60.0, gt=0, le=400)


class CountdownRequest(_Req):
    scenario: MissionScenario
    at: datetime | None = None
    max_days: float = Field(35.0, gt=0, le=120)


class SweepRequest(_Req):
    scenarios: list[MissionScenario] = Field(min_length=1, max_length=12)   # uno per sito
    n_days: int = Field(30, ge=1, le=370)
    stride_days: float = Field(1.0, gt=0, le=30)
    window_hours: float = Field(24.0, gt=0, le=720)
    step_minutes: float = Field(30.0, ge=1)


class StayRequest(_Req):
    """Per ogni data di arrivo valuta una permanenza di stay_hours (default 156 h = 6.5 giorni)."""
    scenario: MissionScenario          # contano sito, data di inizio, altezza osservatore, antenna; la durata no
    n_days: int = Field(60, ge=1, le=400)
    stay_hours: float = Field(156.0, gt=0, le=720)
    stride_hours: float = Field(6.0, gt=0, le=240)
    step_minutes: float = Field(30.0, ge=1)
    continuous_sunlight: bool = True
    max_earth_blackout_h: float | None = Field(None, ge=0)
    min_earth_visible_percent: float | None = Field(None, ge=0, le=100)


def load_sites() -> list[dict]:
    try:
        return json.loads(cfg.SITES_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []


class _Holder:
    """Costruzione pigra del motore: l'import del modulo non fallisce se mancano i kernel."""
    def __init__(self, engine: MissionEngine | None) -> None:
        self._engine = engine

    def get(self) -> MissionEngine:
        if self._engine is None:
            self._engine = MissionEngine(build_ephemeris(), DemCatalog.from_directory(cfg.DEM_DIR))
        return self._engine


def create_app(engine: MissionEngine | None = None) -> FastAPI:
    app = FastAPI(title="GrazingLink Mission Planning API", version=__version__,
                  description="Sun/Earth geometry, terrain horizon, illumination, Earth visibility and "
                              "simplified RF link for lunar landing-site comparison.")
    holder = _Holder(engine)

    def eng() -> MissionEngine:
        try:
            return holder.get()
        except Exception as exc:  # kernel/astropy mancanti
            raise HTTPException(503, f"Engine unavailable: {exc}") from exc

    def guard(fn, *a, **kw):
        try:
            return fn(*a, **kw)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/health")
    def health() -> dict:
        e = eng()
        return {"status": "ok", "version": __version__, "ephemeris": e.eph.describe(), "dems": e.catalog.describe()}

    @app.get("/artemis/regions")
    def artemis_regions() -> dict:
        """Regioni candidate Artemis: nomi, liste NASA, puntatori ai DEM e stato (coordinate / DEM)."""
        return regions_with_status(eng().catalog)

    @app.post("/stay-windows")
    def stay_windows(req: StayRequest) -> dict:
        return guard(eng().stay_windows, req.scenario, req.n_days, req.stay_hours, req.stride_hours,
                     req.step_minutes, req.continuous_sunlight, req.max_earth_blackout_h,
                     req.min_earth_visible_percent)

    @app.get("/sites")
    def sites() -> list[dict]:
        return load_sites()

    @app.post("/simulate")
    def simulate(sc: MissionScenario, decimate: int = Query(1, ge=1, le=100),
                 series: bool = True, refine: bool = True) -> dict:
        return eng().run(sc, refine=refine).to_dict(decimate=decimate, include_series=series)

    @app.post("/compare")
    def compare_scenarios(req: CompareRequest) -> dict:
        e = eng()
        results = [e.run(s) for s in req.scenarios]
        out = guard(compare, results)
        if req.include_series:
            out["results"] = [r.to_dict() for r in results]
        return out

    @app.post("/compare/shift")
    def compare_shift(req: CompareShiftRequest) -> dict:
        e = eng()
        scs = [req.scenario] + [shifted(req.scenario, d) for d in req.shift_days]
        results = [e.run(s) for s in scs]
        out = guard(compare, results)
        if req.include_series:
            out["results"] = [r.to_dict() for r in results]
        return out

    @app.post("/horizon")
    def horizon(req: HorizonRequest) -> dict:
        lon = ((req.longitude + 180.0) % 360.0) - 180.0
        return eng().horizon_profile(req.latitude, lon, req.observer_height_m, req.n_azimuths, req.range_km)

    @app.post("/countdown")
    def countdown(req: CountdownRequest) -> dict:
        return eng().countdown(req.scenario, req.at, req.max_days)

    @app.post("/sweep")
    def sweep(req: SweepRequest) -> dict:
        e = eng()
        return {"sites": [guard(e.sweep, s, req.n_days, req.stride_days, req.window_hours, req.step_minutes)
                          for s in req.scenarios]}

    return app


app = create_app()
