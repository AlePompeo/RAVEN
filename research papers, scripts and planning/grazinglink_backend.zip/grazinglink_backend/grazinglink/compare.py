"""Confronto tra scenari.

Niente punteggio unico: ogni metrica ha la sua riga, il "migliore" e' indicato per metrica con la
direzione dichiarata, cosi' l'utente vede quali compromessi sta accettando. Il confronto e' valido
solo con stessa durata e stesso passo; la data di inizio puo' differire (confronto tra date).
"""
from __future__ import annotations

from datetime import timedelta

from .mission import ScenarioResult
from .models import MissionScenario

# (metrica, direzione migliore, etichetta)
METRICS = [
    ("sunlit_percent", "higher", "Sunlit time (%)"),
    ("longest_dark_h", "lower", "Longest darkness (h)"),
    ("solar_energy_wh", "higher", "Solar energy (Wh)"),
    ("earth_visible_percent", "higher", "Earth visible (%)"),
    ("longest_earth_blackout_h", "lower", "Longest Earth blackout (h)"),
    ("sun_and_earth_percent", "higher", "Sun and Earth together (%)"),
    ("rf_available_percent", "higher", "RF link above threshold (%)"),
    ("rf_longest_outage_h", "lower", "Longest RF outage (h)"),
    ("rf_margin_mean_db_in_windows", "higher", "Mean margin in windows (dB)"),
    ("rf_margin_min_db_in_windows", "higher", "Min margin in windows (dB)"),
    ("rf_median_max_bitrate_bps_in_windows", "higher", "Median max bitrate (bps)"),
]


def shifted(sc: MissionScenario, days: float) -> MissionScenario:
    """Stesso sito, data spostata (caso: il lancio slitta)."""
    return sc.model_copy(update={"id": f"{sc.id}{days:+g}d", "start_time": sc.start_time + timedelta(days=days)})


def _flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        if isinstance(v, dict):
            out.update(_flatten(v, f"{prefix}{k}."))
        else:
            out[f"{prefix}{k}"] = v
    return out


def changed_parameters(scenarios: list[MissionScenario]) -> dict[str, dict]:
    flat = [_flatten(s.model_dump(mode="json")) for s in scenarios]
    keys = [k for k in flat[0] if k not in ("id", "name")]
    return {k: {s.id: f[k] for s, f in zip(scenarios, flat)} for k in keys
            if any(f.get(k) != flat[0].get(k) for f in flat)}


def compare(results: list[ScenarioResult]) -> dict:
    if len(results) < 2:
        raise ValueError("servono almeno due scenari")
    ref = results[0].scenario
    for r in results[1:]:
        if r.scenario.duration_hours != ref.duration_hours or r.scenario.time_step_minutes != ref.time_step_minutes:
            raise ValueError("confronto non valido: durata e passo temporale devono coincidere")
    ids = [r.scenario.id for r in results]
    if len(set(ids)) != len(ids):
        raise ValueError("gli id degli scenari devono essere distinti")
    rows = []
    for key, direction, label in METRICS:
        vals = {r.scenario.id: r.summary.get(key) for r in results}
        present = {k: v for k, v in vals.items() if v is not None}
        best = None
        if len(present) == len(vals) and len(set(present.values())) > 1:
            pick = max if direction == "higher" else min
            best = pick(present, key=present.get)
        if present:
            rows.append({"metric": key, "label": label, "better": direction, "values": vals, "best": best,
                         "delta_vs_first": {k: (None if v is None or vals[ids[0]] is None else round(v - vals[ids[0]], 3))
                                            for k, v in vals.items()}})
    return {"scenarios": ids, "changed_parameters": changed_parameters([r.scenario for r in results]),
            "metrics": rows, "warnings": sorted({w for r in results for w in r.provenance["warnings"]}),
            "note": "No composite score: each metric is shown separately with its preferred direction."}
