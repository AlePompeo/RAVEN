"""Sunlight Engine e Earth Visibility Engine (parte geometrica).

Il Sole e la Terra non sono punti: il disco viene campionato (girasole, 85 punti) e si calcola
la frazione sopra l'orizzonte locale. Cosi' tramonti e occultamenti sono graduali e le ombre
parziali emergono dal terreno. Nessuna rifrazione (la Luna non ha atmosfera); niente limb darkening.
"""
from __future__ import annotations

import numpy as np

from . import config as cfg
from .horizon import HorizonProfile
from .models import PanelMode, SolarPanel


def enu_to_azel(v: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Versori (n,3) in (Est, Nord, Su) -> azimut (0=Nord, orario) ed elevazione, in gradi."""
    az = np.degrees(np.arctan2(v[:, 0], v[:, 1])) % 360.0
    el = np.degrees(np.arcsin(np.clip(v[:, 2], -1.0, 1.0)))
    return az, el


def _disc_samples(n: int = 85) -> tuple[np.ndarray, np.ndarray]:
    k = np.arange(n) + 0.5
    r, th = np.sqrt(k / n), k * np.pi * (3.0 - np.sqrt(5.0))
    return r * np.cos(th), r * np.sin(th)


_DX, _DY = _disc_samples()


def disc_visible_fraction(profile: HorizonProfile, az_c, el_c, radius_deg) -> np.ndarray:
    """Frazione (0..1) del disco di raggio radius_deg centrato in (az_c, el_c) sopra l'orizzonte."""
    az_c, el_c, rad = (np.atleast_1d(np.asarray(a, float)) for a in (az_c, el_c, radius_deg))
    cos_el = np.cos(np.radians(np.clip(el_c, -85.0, 85.0)))
    az_p = az_c[:, None] + rad[:, None] * _DX[None, :] / cos_el[:, None]
    el_p = el_c[:, None] + rad[:, None] * _DY[None, :]
    return (el_p > profile.at(az_p)).mean(axis=1)


def solar_power_w(panel: SolarPanel, sun_enu: np.ndarray, sun_dist_km: np.ndarray,
                  visible_fraction: np.ndarray) -> np.ndarray:
    """P = A * eta * S(d) * frazione_visibile * max(0, cos(angolo di incidenza)).

    Stima geometrica di primo livello: niente temperatura, degrado, ombre del lander.
    """
    flux = cfg.SOLAR_CONSTANT_W_M2 * (cfg.AU_KM / sun_dist_km) ** 2
    if panel.mode == PanelMode.vertical_tracking:
        cos_inc = np.hypot(sun_enu[:, 0], sun_enu[:, 1])            # normale orizzontale verso il Sole
    else:
        tilt, az = np.radians(panel.tilt_deg), np.radians(panel.azimuth_deg)
        normal = np.array([np.sin(tilt) * np.sin(az), np.sin(tilt) * np.cos(az), np.cos(tilt)])
        cos_inc = sun_enu @ normal
    return panel.area_m2 * panel.efficiency * flux * visible_fraction * np.maximum(cos_inc, 0.0)
