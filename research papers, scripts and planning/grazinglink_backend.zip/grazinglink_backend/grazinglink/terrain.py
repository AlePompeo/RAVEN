"""Dati topografici (DEM).

Convenzioni (da verificare sui metadati del DEM che userete):
  * proiezione: stereografica polare SUD sferica (R = 1737.4 km), polo al centro, x = rho*sin(lon),
    y = rho*cos(lon) -> e' la convenzione dei prodotti LOLA LDEM_80S/85S;
  * quote in metri rispetto alla sfera di riferimento di 1737.4 km (NaN = nessun dato);
  * pixel quadrati, riga 0 = y massima (GeoTIFF "nord in alto").
Per DEM in altre proiezioni o per l'emisfero nord serve estendere latlon_to_xy_south().
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Protocol

import numpy as np

from .config import MOON_RADIUS_M


# --------------------------------------------------------------------------- proiezione
def latlon_to_xy_south(lat_deg, lon_deg, radius_m: float = MOON_RADIUS_M):
    lat, lon = np.radians(lat_deg), np.radians(lon_deg)
    rho = 2.0 * radius_m * np.tan(np.pi / 4.0 + lat / 2.0)      # = 0 al polo sud
    return rho * np.sin(lon), rho * np.cos(lon)


def xy_to_latlon_south(x, y, radius_m: float = MOON_RADIUS_M):
    rho = np.hypot(x, y)
    return -90.0 + 2.0 * np.degrees(np.arctan(rho / (2.0 * radius_m))), np.degrees(np.arctan2(x, y))


# --------------------------------------------------------------------------- DEM
@dataclass
class Dem:
    dem_id: str
    z: np.ndarray            # (ny, nx), metri, NaN = no data
    x0: float                # x del centro del pixel [.., 0]
    y0: float                # y del centro del pixel [0, ..]
    res_m: float
    source: str = "memory"

    def bounds(self) -> tuple[float, float, float, float]:
        ny, nx = self.z.shape
        return self.x0, self.x0 + (nx - 1) * self.res_m, self.y0 - (ny - 1) * self.res_m, self.y0

    def contains(self, x: float, y: float) -> bool:
        xmin, xmax, ymin, ymax = self.bounds()
        return xmin <= x <= xmax and ymin <= y <= ymax

    def sample(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        """Interpolazione bilineare; NaN fuori dal raster o su celle senza dato."""
        ny, nx = self.z.shape
        col = (np.asarray(x) - self.x0) / self.res_m
        row = (self.y0 - np.asarray(y)) / self.res_m
        r0, c0 = np.floor(row).astype(np.int64), np.floor(col).astype(np.int64)
        inside = (r0 >= 0) & (r0 < ny - 1) & (c0 >= 0) & (c0 < nx - 1)
        r0c, c0c = np.clip(r0, 0, ny - 2), np.clip(c0, 0, nx - 2)
        fr, fc = row - r0c, col - c0c
        z = self.z
        val = ((1 - fr) * ((1 - fc) * z[r0c, c0c] + fc * z[r0c, c0c + 1])
               + fr * ((1 - fc) * z[r0c + 1, c0c] + fc * z[r0c + 1, c0c + 1]))
        return np.where(inside, val, np.nan)

    @classmethod
    def from_function(cls, f: Callable[[np.ndarray, np.ndarray], np.ndarray], half_size_m: float,
                      res_m: float, dem_id: str = "synthetic",
                      center_xy: tuple[float, float] = (0.0, 0.0)) -> "Dem":
        """DEM sintetico attorno a center_xy (m, proiezione polare; default = polo).

        Per test e demo: NON e' terreno lunare reale. Un sito a 85 S sta a ~152 km dal polo:
        centra il DEM sul sito con center_xy=latlon_to_xy_south(lat, lon).
        """
        cx, cy = float(center_xy[0]), float(center_xy[1])
        xs = cx + np.arange(-half_size_m, half_size_m + res_m, res_m)
        ys = cy + np.arange(half_size_m, -half_size_m - res_m, -res_m)
        xx, yy = np.meshgrid(xs, ys)
        return cls(dem_id, f(xx, yy).astype(np.float64), float(xs[0]), float(ys[0]), float(res_m), "synthetic")


class DemStack:
    """Piu' DEM sovrapposti, dal piu' fine al piu' grosso: ogni punto usa il primo che ha un dato.

    Serve per i DEM regionali a 5 m (pochi km di lato): dentro il DEM fine si usa il dettaglio,
    fuori si ripiega sul DEM polare a 20-40 m invece che sulla sfera nuda. Alla giunzione possono
    esserci piccoli salti di quota (i DEM hanno errori diversi): il motore non li "cuce".
    """

    def __init__(self, layers: list[Dem]) -> None:
        self.layers = list(layers)
        self.res_m = self.layers[0].res_m
        self.dem_id = " + ".join(layer.dem_id for layer in self.layers)
        self.source = "stack"

    def sample(self, x, y) -> np.ndarray:
        out = self.layers[0].sample(x, y)
        for layer in self.layers[1:]:
            missing = np.isnan(out)
            if not missing.any():
                break
            out = np.where(missing, layer.sample(x, y), out)
        return out

    def contains(self, x: float, y: float) -> bool:
        return any(layer.contains(x, y) for layer in self.layers)


# --------------------------------------------------------------------------- sorgenti
class DemSource(Protocol):
    dem_id: str
    res_m: float

    def covers(self, lat_deg: float, lon_deg: float) -> bool: ...
    def load(self, lat_deg: float, lon_deg: float, range_m: float) -> Dem: ...


class MemoryDemSource:
    def __init__(self, dem: Dem) -> None:
        self.dem, self.dem_id, self.res_m = dem, dem.dem_id, dem.res_m

    def covers(self, lat_deg, lon_deg) -> bool:
        return self.dem.contains(*latlon_to_xy_south(lat_deg, lon_deg))

    def load(self, lat_deg, lon_deg, range_m) -> Dem:
        return self.dem


class GeoTiffDemSource:
    """GeoTIFF (es. LOLA LDEM convertito con gdal_translate). Legge solo la finestra utile."""

    def __init__(self, path: Path | str, scale: float = 1.0, offset: float = 0.0,
                 dem_id: str | None = None) -> None:
        self.path, self.scale, self.offset = Path(path), scale, offset
        self.dem_id = dem_id or self.path.stem
        rasterio = self._rasterio()
        with rasterio.open(self.path) as ds:
            if ds.transform.e >= 0:
                raise ValueError(f"{self.path.name}: raster con asse y crescente non supportato")
            self.res_m = float(abs(ds.transform.a))
            self._bounds = tuple(ds.bounds)      # left, bottom, right, top (m)

    @staticmethod
    def _rasterio():
        try:
            import rasterio
            return rasterio
        except ImportError as exc:
            raise ImportError("Per leggere GeoTIFF installa rasterio (pip install rasterio)") from exc

    def covers(self, lat_deg, lon_deg) -> bool:
        x, y = latlon_to_xy_south(lat_deg, lon_deg)
        left, bottom, right, top = self._bounds
        return left <= x <= right and bottom <= y <= top

    def load(self, lat_deg, lon_deg, range_m) -> Dem:
        rasterio = self._rasterio()
        from rasterio.windows import Window
        x, y = latlon_to_xy_south(lat_deg, lon_deg)
        with rasterio.open(self.path) as ds:
            r_c, c_c = ds.index(float(x), float(y))
            half = int(np.ceil(range_m / self.res_m)) + 2
            r0, r1 = max(0, r_c - half), min(ds.height, r_c + half + 1)
            c0, c1 = max(0, c_c - half), min(ds.width, c_c + half + 1)
            win = Window(c0, r0, c1 - c0, r1 - r0)
            arr = ds.read(1, window=win).astype(np.float64)
            if ds.nodata is not None:
                arr[arr == ds.nodata] = np.nan
            tf = ds.window_transform(win)
        z = arr * self.scale + self.offset
        valid = z[np.isfinite(z)]
        if valid.size and float(np.median(np.abs(valid))) > 50_000.0:
            raise ValueError(
                f"{self.path.name}: la mediana delle quote supera 50 km: sembra il RAGGIO planetario "
                "(DN*0.5 + 1737400) e non l'altezza sulla sfera di riferimento. Converti con "
                "scripts/prepare_lola_dem.py oppure usa offset=-1737400.")
        return Dem(self.dem_id, z, tf.c + tf.a / 2, tf.f + tf.e / 2, self.res_m, str(self.path.name))


class DemCatalog:
    """Sceglie il DEM a risoluzione piu' fine che copre il sito."""

    def __init__(self, sources: list | None = None) -> None:
        self.sources: list = sorted(sources or [], key=lambda s: s.res_m)
        self._cache: dict = {}

    @classmethod
    def from_directory(cls, path: Path | str) -> "DemCatalog":
        path = Path(path)
        srcs = []
        if path.is_dir():
            for p in sorted([*path.glob("*.tif"), *path.glob("*.tiff")]):
                try:
                    srcs.append(GeoTiffDemSource(p))
                except ImportError:
                    break          # rasterio assente: catalogo vuoto, il motore usa la sola sfera
        return cls(srcs)

    def register(self, source) -> None:
        self.sources = sorted([*self.sources, source], key=lambda s: s.res_m)

    def find(self, lat_deg: float, lon_deg: float):
        return next((s for s in self.sources if s.covers(lat_deg, lon_deg)), None)

    def load(self, lat_deg: float, lon_deg: float, range_m: float):
        """Dem singolo, oppure DemStack (fine -> grosso) se piu' DEM coprono il sito; None se nessuno."""
        srcs = [s for s in self.sources if s.covers(lat_deg, lon_deg)]
        if not srcs:
            return None
        key = (tuple(s.dem_id for s in srcs), round(lat_deg, 4), round(lon_deg, 4), round(range_m))
        if key not in self._cache:
            if len(self._cache) > 16:
                self._cache.pop(next(iter(self._cache)))
            layers = [s.load(lat_deg, lon_deg, range_m) for s in srcs]
            self._cache[key] = layers[0] if len(layers) == 1 else DemStack(layers)
        return self._cache[key]

    def describe(self) -> list[dict]:
        return [{"id": s.dem_id, "resolution_m": s.res_m} for s in self.sources]
