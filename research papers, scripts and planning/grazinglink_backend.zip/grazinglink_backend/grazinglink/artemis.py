"""Catalogo delle regioni candidate Artemis (data/artemis_regions.json).

Il catalogo contiene nomi, appartenenza alle liste NASA (13 regioni nel 2022, 9 nel 2024) e puntatori
ai DEM. NON contiene coordinate inventate: latitude/longitude sono null finche' non le imposti da una
fonte ufficiale o verificata (scripts/add_artemis_site.py). Senza coordinate una regione non e' simulabile.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import config as cfg
from .terrain import DemCatalog, xy_to_latlon_south


def load_artemis(path: Path | str | None = None) -> dict:
    return json.loads(Path(path or cfg.ARTEMIS_FILE).read_text(encoding="utf-8"))


def save_artemis(data: dict, path: Path | str | None = None) -> None:
    Path(path or cfg.ARTEMIS_FILE).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def set_region_coordinates(region_id: str, lat: float, lon: float, source: str, verified: bool = False,
                           path: Path | str | None = None) -> dict:
    """Scrive le coordinate di una regione nel catalogo. Le regioni NASA stanno entro 6 gradi dal polo sud."""
    if not -90.0 <= lat <= -84.0:
        raise ValueError(f"lat {lat}: le regioni Artemis stanno entro 6 gradi dal polo sud (da -90 a -84)")
    lon = ((lon + 180.0) % 360.0) - 180.0
    if not source.strip():
        raise ValueError("indica la fonte delle coordinate")
    data = load_artemis(path)
    region = next((r for r in data["regions"] if r["id"] == region_id), None)
    if region is None:
        raise KeyError(f"regione sconosciuta: {region_id}. Valide: {[r['id'] for r in data['regions']]}")
    region.update(latitude=round(lat, 5), longitude=round(lon, 5), coordinates_source=source,
                  coordinates_verified=bool(verified))
    save_artemis(data, path)
    return region


def dem_center_latlon(dem_path: Path | str) -> tuple[float, float]:
    """Lat/lon del CENTRO di un GeoTIFF polare sud (non e' detto che coincida col sito: verificare)."""
    import rasterio
    with rasterio.open(dem_path) as ds:
        left, bottom, right, top = ds.bounds
    lat, lon = xy_to_latlon_south((left + right) / 2.0, (bottom + top) / 2.0)
    return float(lat), float(lon)


def region_status(region: dict, catalog: DemCatalog | None) -> dict:
    """needs_coordinates -> no_dem -> ready, con i DEM che coprono la regione."""
    if region.get("latitude") is None or region.get("longitude") is None:
        return {"status": "needs_coordinates", "dems": []}
    covering = [] if catalog is None else [{"id": s.dem_id, "resolution_m": s.res_m} for s in catalog.sources
                                           if s.covers(region["latitude"], region["longitude"])]
    return {"status": "ready" if covering else "no_dem", "dems": covering}


def regions_with_status(catalog: DemCatalog | None, path: Path | str | None = None) -> dict:
    data = load_artemis(path)
    return {"meta": data["meta"],
            "regions": [{**r, **region_status(r, catalog)} for r in data["regions"]]}
