"""RF Engine (stima semplificata, parametri illustrativi).

    C/N0   = EIRP + G/T - L_tot + 228.6          [dB-Hz]
    Eb/N0  = C/N0 - 10 log10(Rb)
    Margin = Eb/N0 - (Eb/N0)_richiesto

Incluso: perdita di spazio libero, diffrazione knife-edge singola (ITU-R P.526) sul profilo del
terreno verso la Terra, puntamento, perdite di linea/altre. NON incluso: multipath (two-ray),
cresta arrotondata (GPR), relay, modulazione/codifica reali. G/T della stazione e' dato in input
e NON va corretto di nuovo per la temperatura di rumore (e' gia' un rapporto).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from . import config as cfg
from .models import Antenna


def fspl_db(distance_m, frequency_hz) -> np.ndarray:
    return 20.0 * np.log10(4.0 * np.pi * np.asarray(distance_m) * frequency_hz / cfg.C_LIGHT_M_S)


def fresnel_nu(clearance_m, range_m, frequency_hz) -> np.ndarray:
    """Parametro di Fresnel-Kirchhoff con il ricevitore all'infinito (Terra): nu = h*sqrt(2/(lambda*d1)).

    clearance_m > 0 = l'ostacolo sta SOPRA la linea di vista; < 0 = c'e' margine libero.
    """
    lam = cfg.C_LIGHT_M_S / frequency_hz
    return np.asarray(clearance_m) * np.sqrt(2.0 / (lam * np.asarray(range_m)))


def knife_edge_loss_db(nu) -> np.ndarray:
    """J(nu) = 6.9 + 20 log10( sqrt((nu-0.1)^2 + 1) + nu - 0.1 ), nullo per nu <= -0.78 (ITU-R P.526)."""
    nu = np.asarray(nu, float)
    v = np.maximum(nu, cfg.FRESNEL_CLEAR_NU)
    j = 6.9 + 20.0 * np.log10(np.sqrt((v - 0.1) ** 2 + 1.0) + v - 0.1)
    return np.where(nu > cfg.FRESNEL_CLEAR_NU, j, 0.0)


def classify_path(nu: np.ndarray) -> np.ndarray:
    """Le quattro condizioni da mostrare separatamente nell'interfaccia."""
    return np.select(
        [nu <= cfg.FRESNEL_CLEAR_NU, nu <= 0.0, nu <= cfg.DIFFRACTION_NU_LIMIT],
        ["los_clear", "fresnel_zone_obstructed", "diffracted"],
        default="shadowed_beyond_model")


@dataclass
class LinkBudget:
    fspl_db: np.ndarray
    cn0_dbhz: np.ndarray
    ebn0_db: np.ndarray
    margin_db: np.ndarray
    max_bitrate_bps: np.ndarray      # bitrate per cui il margine scende a margin_threshold


def link_budget(ant: Antenna, distance_m, diffraction_db, margin_threshold_db: float) -> LinkBudget:
    eirp = 10.0 * np.log10(ant.tx_power_w) + ant.tx_gain_dbi - ant.line_loss_db
    fspl = fspl_db(distance_m, ant.frequency_hz)
    losses = fspl + diffraction_db + ant.pointing_loss_db + ant.other_loss_db
    cn0 = eirp + ant.station_gt_dbk - losses - cfg.BOLTZMANN_DBW_HZ_K
    ebn0 = cn0 - 10.0 * np.log10(ant.bitrate_bps)
    margin = ebn0 - ant.required_ebn0_db
    max_rb = 10.0 ** ((cn0 - ant.required_ebn0_db - margin_threshold_db) / 10.0)
    return LinkBudget(fspl, cn0, ebn0, margin, max_rb)
