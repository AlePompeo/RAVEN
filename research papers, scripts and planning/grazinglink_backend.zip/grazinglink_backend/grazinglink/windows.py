"""Finestre temporali: intervalli contigui in cui una condizione e' vera.

La griglia temporale e' grossolana (es. 10 min): i bordi si raffinano per bisezione chiamando di
nuovo il motore sugli istanti intermedi, con la STESSA funzione-condizione usata sulla griglia.
Per ogni finestra si conserva anche la condizione che l'ha chiusa (reason al primo campione falso).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

Predicate = Callable[[np.ndarray], np.ndarray]


@dataclass
class Window:
    start_s: float
    end_s: float
    opened_by: str      # "start_of_simulation" | "transition"
    closed_by: str      # motivo letto sul primo campione falso, oppure "end_of_simulation"

    @property
    def duration_s(self) -> float:
        return self.end_s - self.start_s


def bisect_edges(lo, hi, predicate: Predicate, state_at_lo: bool, n_iter: int = 14) -> np.ndarray:
    """Per ogni coppia (lo, hi) con condizione == state_at_lo in lo e opposta in hi, trova il bordo."""
    lo, hi = np.array(lo, float), np.array(hi, float)
    for _ in range(n_iter):
        mid = 0.5 * (lo + hi)
        same = np.asarray(predicate(mid), bool) == state_at_lo
        lo, hi = np.where(same, mid, lo), np.where(same, hi, mid)
    return 0.5 * (lo + hi)


def extract_windows(t_s: np.ndarray, mask: np.ndarray, reasons: np.ndarray | None = None,
                    refine: Predicate | None = None) -> list[Window]:
    t_s, mask = np.asarray(t_s, float), np.asarray(mask, bool)
    if mask.size == 0:
        return []
    d = np.diff(mask.astype(np.int8))
    rise, fall = np.flatnonzero(d == 1), np.flatnonzero(d == -1)

    def edges(idx: np.ndarray, state_at_lo: bool) -> list[float]:
        if idx.size == 0:
            return []
        lo, hi = t_s[idx], t_s[idx + 1]
        return list(bisect_edges(lo, hi, refine, state_at_lo) if refine else 0.5 * (lo + hi))

    starts, opened = edges(rise, False), ["transition"] * rise.size
    ends = edges(fall, True)
    closed = [str(reasons[i + 1]) if reasons is not None else "condition_false" for i in fall]
    if mask[0]:
        starts.insert(0, float(t_s[0]))
        opened.insert(0, "start_of_simulation")
    if mask[-1]:
        ends.append(float(t_s[-1]))
        closed.append("end_of_simulation")
    return [Window(float(s), float(e), o, c) for s, e, o, c in zip(starts, ends, opened, closed)]


def complement(t_s: np.ndarray, mask: np.ndarray, refine: Predicate | None = None) -> list[Window]:
    """Gli intervalli in cui la condizione e' FALSA (buio, blackout, interruzioni del link)."""
    inv = (lambda t: ~np.asarray(refine(t), bool)) if refine else None
    return extract_windows(t_s, ~np.asarray(mask, bool), None, inv)


def next_edge(t_s: np.ndarray, mask: np.ndarray, refine: Predicate | None = None) -> float | None:
    """Istante del primo cambio di stato rispetto al primo campione, o None se non avviene."""
    mask = np.asarray(mask, bool)
    flips = np.flatnonzero(mask != mask[0])
    if flips.size == 0:
        return None
    i = int(flips[0])
    lo, hi = float(t_s[i - 1]), float(t_s[i])
    if refine is None:
        return 0.5 * (lo + hi)
    return float(bisect_edges([lo], [hi], refine, bool(mask[0]))[0])


def humanize(seconds: float) -> str:
    s = int(round(seconds))
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m = s // 60
    return " ".join(p for p in (f"{d} d" if d else "", f"{h} h" if h or d else "", f"{m} min") if p)
