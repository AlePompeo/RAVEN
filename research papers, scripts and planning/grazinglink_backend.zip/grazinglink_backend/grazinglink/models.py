"""Modello dati dello scenario (MissionScenario).

Gli alias camelCase mantengono compatibile il JSON di esempio del documento di progetto
(startTime, durationHours, observerHeightMeters, solarPanel, rfThresholdDb, ...).
I valori di default sono ILLUSTRATIVI, non parametri di una missione reale.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .config import MAX_TIME_STEPS


class _Model(BaseModel):
    # extra="forbid": un parametro scritto male deve dare errore, non essere ignorato in silenzio.
    model_config = ConfigDict(populate_by_name=True, extra="forbid")


class PanelMode(str, Enum):
    fixed = "fixed"                        # normale fissa (tilt_deg / azimuth_deg)
    vertical_tracking = "vertical_tracking"  # pannello verticale che segue l'azimut del Sole


class SolarPanel(_Model):
    area_m2: float = Field(2.0, gt=0, alias="areaM2")
    efficiency: float = Field(0.28, gt=0, le=1)
    mode: PanelMode = PanelMode.vertical_tracking
    # Angolo tra la normale del pannello e la verticale locale: 0 = orizzontale, 90 = verticale.
    tilt_deg: float = Field(90.0, ge=0, le=180, alias="tiltDegrees")
    azimuth_deg: float = Field(0.0, ge=0, lt=360, alias="azimuthDegrees")  # solo mode=fixed

    @model_validator(mode="after")
    def _tilt_implies_fixed(self) -> "SolarPanel":
        # Chi indica un tilt senza indicare il modo intende un pannello fisso.
        if "tilt_deg" in self.model_fields_set and "mode" not in self.model_fields_set:
            self.mode = PanelMode.fixed
        return self


class Antenna(_Model):
    """Parametri RF illustrativi: sostituirli con quelli della missione."""
    type: str | None = None
    frequency_hz: float = Field(8.4e9, gt=0, alias="frequencyHz")
    tx_power_w: float = Field(10.0, gt=0, alias="txPowerW")
    tx_gain_dbi: float = Field(8.0, alias="txGainDbi")
    line_loss_db: float = Field(1.0, ge=0, alias="lineLossDb")
    pointing_loss_db: float = Field(0.5, ge=0, alias="pointingLossDb")
    other_loss_db: float = Field(1.0, ge=0, alias="otherLossDb")
    station_gt_dbk: float = Field(50.0, alias="stationGtDbK")     # G/T della stazione di terra
    bitrate_bps: float = Field(30_000.0, gt=0, alias="bitrateBps")
    required_ebn0_db: float = Field(2.5, alias="requiredEbN0Db")


class MissionScenario(_Model):
    id: str
    name: str = ""
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-360, le=360)              # est positivo, frame ME
    start_time: datetime = Field(alias="startTime")
    duration_hours: float = Field(48.0, gt=0, alias="durationHours")
    time_step_minutes: float = Field(10.0, gt=0, alias="timeStepMinutes")
    observer_height_m: float = Field(2.0, ge=0, le=100, alias="observerHeightMeters")
    solar_panel: SolarPanel = Field(default_factory=SolarPanel, alias="solarPanel")
    antenna: Antenna | None = None                          # None = analisi RF disattivata
    rf_threshold_db: float = Field(3.0, alias="rfThresholdDb")  # margine minimo per "link OK"
    horizon_range_km: float = Field(60.0, gt=0, le=400, alias="horizonRangeKm")
    n_azimuths: int = Field(720, ge=72, le=7200, alias="nAzimuths")
    sun_min_visible_fraction: float = Field(0.01, ge=0, lt=1)
    earth_min_visible_fraction: float = Field(0.01, ge=0, lt=1)

    @field_validator("start_time")
    @classmethod
    def _to_utc(cls, v: datetime) -> datetime:
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v.astimezone(timezone.utc)

    @field_validator("longitude")
    @classmethod
    def _wrap_lon(cls, v: float) -> float:
        return ((v + 180.0) % 360.0) - 180.0

    @model_validator(mode="after")
    def _check_size(self) -> "MissionScenario":
        if self.n_steps > MAX_TIME_STEPS:
            raise ValueError(
                f"{self.n_steps} time steps exceed the limit of {MAX_TIME_STEPS}: "
                "increase timeStepMinutes or shorten durationHours")
        return self

    @property
    def n_steps(self) -> int:
        return int(self.duration_hours * 60.0 / self.time_step_minutes) + 1
