"""GrazingLink Mission Planning backend: un solo motore scientifico, nessuna logica nel frontend."""

__version__ = "0.1.0"
