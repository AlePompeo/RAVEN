"""Geometria Sole/Terra/sito: direzioni nel frame locale del sito (Est, Nord, Su).

Due backend con la stessa interfaccia:
  * SpiceEphemeris   - NASA/JPL SPICE (spiceypy). E' quello da usare per risultati veri.
  * AnalyticEphemeris - astropy (effemeridi built-in, bassa precisione) + rotazione IAU 2009.
                        SOLO sviluppo/test quando mancano i kernel: dichiara sempre il warning.

L'orientamento lunare puo' venire dal PCK ad alta precisione (frame MOON_ME_DE440_ME421, serve
moon_pa_de440_*.bpc + moon_de440_*.tf) oppure dal modello IAU 2009 (solo de440s.bsp + leapseconds):
quest'ultimo e' meno accurato (ordine di centinaia di metri sulla superficie) e viene segnalato.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from . import config as cfg

_KERNEL_SUFFIXES = (".tls", ".bsp", ".bpc", ".tpc", ".tf")


@dataclass(frozen=True)
class SkyGeometry:
    """Sole e Terra visti dal sito. I versori sono in coordinate (Est, Nord, Su)."""
    sun_enu: np.ndarray            # (n, 3)
    earth_enu: np.ndarray          # (n, 3)
    sun_dist_km: np.ndarray        # (n,)
    earth_dist_km: np.ndarray
    sun_radius_deg: np.ndarray     # raggio angolare apparente del disco
    earth_radius_deg: np.ndarray


# --------------------------------------------------------------------------- geometria locale
def local_basis(lat_deg: float, lon_deg: float) -> np.ndarray:
    """Matrice 3x3 con righe (Est, Nord, Su) espresse nel frame fisso lunare."""
    lat, lon = np.radians(lat_deg), np.radians(lon_deg)
    east = np.array([-np.sin(lon), np.cos(lon), 0.0])
    north = np.array([-np.sin(lat) * np.cos(lon), -np.sin(lat) * np.sin(lon), np.cos(lat)])
    up = np.array([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)])
    return np.stack([east, north, up])


# --------------------------------------------------------------------------- rotazione IAU 2009
_E_ANGLES = (  # (valore a J2000 [deg], velocita' [deg/giorno]) per E1..E13 (IAU WGCCRE 2009, Luna)
    (125.045, -0.0529921), (250.089, -0.1059842), (260.008, 13.0120009), (176.625, 13.3407154),
    (357.529, 0.9856003), (311.589, 26.4057084), (134.963, 13.0649930), (276.617, 0.3287146),
    (34.226, 1.7484877), (15.134, -0.1589763), (119.743, 0.0036096), (239.961, 0.1643573),
    (25.053, 12.9590088),
)


def _rz(a: np.ndarray) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    m = np.zeros((a.size, 3, 3))
    m[:, 0, 0], m[:, 0, 1], m[:, 1, 0], m[:, 1, 1], m[:, 2, 2] = c, s, -s, c, 1.0
    return m


def _rx(a: np.ndarray) -> np.ndarray:
    c, s = np.cos(a), np.sin(a)
    m = np.zeros((a.size, 3, 3))
    m[:, 0, 0], m[:, 1, 1], m[:, 1, 2], m[:, 2, 1], m[:, 2, 2] = 1.0, c, s, -s, c
    return m


def iau2009_moon_matrix(d_days: np.ndarray) -> np.ndarray:
    """Matrici (n,3,3) ICRF -> frame fisso lunare (mean Earth/polar axis), IAU 2009.

    d_days = giorni TDB da J2000.
    """
    d = np.atleast_1d(np.asarray(d_days, float))
    T = d / 36525.0
    E = np.radians(np.stack([e0 + r * d for e0, r in _E_ANGLES]))   # (13, n)
    s, c = np.sin(E), np.cos(E)  # indici 0-based: E1 -> 0
    ra = (269.9949 + 0.0031 * T - 3.8787 * s[0] - 0.1204 * s[1] + 0.0700 * s[2] - 0.0172 * s[3]
          + 0.0072 * s[5] - 0.0052 * s[9] + 0.0043 * s[12])
    dec = (66.5392 + 0.0130 * T + 1.5419 * c[0] + 0.0239 * c[1] - 0.0278 * c[2] + 0.0068 * c[3]
           - 0.0029 * c[5] + 0.0009 * c[6] + 0.0008 * c[9] - 0.0009 * c[12])
    w = (38.3213 + 13.17635815 * d - 1.4e-12 * d * d + 3.5610 * s[0] + 0.1208 * s[1]
         - 0.0642 * s[2] + 0.0158 * s[3] + 0.0252 * s[4] - 0.0066 * s[5] - 0.0047 * s[6]
         - 0.0046 * s[7] + 0.0028 * s[8] + 0.0052 * s[9] + 0.0040 * s[10] + 0.0019 * s[11]
         - 0.0044 * s[12])
    ra, dec, w = np.radians(ra), np.radians(dec), np.radians(w)
    return _rz(w) @ _rx(np.pi / 2 - dec) @ _rz(np.pi / 2 + ra)


# --------------------------------------------------------------------------- classe base
class BaseEphemeris:
    name = "base"
    orientation = "unknown"

    def __init__(self) -> None:
        self.warnings: list[str] = []

    def vectors_body_fixed(self, t0: datetime, offsets_s: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Vettori (km) Luna->Sole e Luna->Terra, centrati sulla Luna, nel frame fisso lunare."""
        raise NotImplementedError

    def sky(self, t0: datetime, offsets_s, lat_deg: float, lon_deg: float,
            observer_height_m: float = 0.0) -> SkyGeometry:
        offsets = np.atleast_1d(np.asarray(offsets_s, float))
        sun, earth = self.vectors_body_fixed(t0, offsets)
        basis = local_basis(lat_deg, lon_deg)
        site = (cfg.MOON_RADIUS_M + observer_height_m) / 1000.0 * basis[2]   # km, parallasse inclusa
        out, dists, radii = [], [], []
        for vec, body_radius_km in ((sun, cfg.SUN_RADIUS_KM), (earth, cfg.EARTH_RADIUS_KM)):
            rel = vec - site
            dist = np.linalg.norm(rel, axis=1)
            out.append((rel @ basis.T) / dist[:, None])
            dists.append(dist)
            radii.append(np.degrees(np.arcsin(body_radius_km / dist)))
        return SkyGeometry(out[0], out[1], dists[0], dists[1], radii[0], radii[1])

    def sub_points(self, t0: datetime, offsets_s) -> dict[str, np.ndarray]:
        """Punti sub-solare e sub-terrestre (lat/lon selenografiche, gradi)."""
        sun, earth = self.vectors_body_fixed(t0, np.atleast_1d(np.asarray(offsets_s, float)))
        res = {}
        for key, v in (("subsolar", sun), ("subearth", earth)):
            res[f"{key}_lat_deg"] = np.degrees(np.arcsin(v[:, 2] / np.linalg.norm(v, axis=1)))
            res[f"{key}_lon_deg"] = np.degrees(np.arctan2(v[:, 1], v[:, 0]))
        return res

    def describe(self) -> dict:
        return {"backend": self.name, "orientation": self.orientation, "warnings": list(self.warnings)}


# --------------------------------------------------------------------------- SPICE
_spice_lock = threading.Lock()      # CSPICE non e' thread-safe
_loaded_kernels: list[str] = []


class SpiceEphemeris(BaseEphemeris):
    name = "NASA/JPL SPICE"

    def __init__(self, kernel_dir: Path | str | None = None, orientation: str | None = None,
                 moon_frame: str | None = None) -> None:
        super().__init__()
        import spiceypy as sp
        self._sp = sp
        self.kernel_dir = Path(kernel_dir or cfg.KERNEL_DIR)
        self.moon_frame = moon_frame or cfg.MOON_FRAME
        files = sorted(p for p in self.kernel_dir.glob("*") if p.suffix.lower() in _KERNEL_SUFFIXES)
        if not any(p.suffix.lower() == ".bsp" for p in files) or not any(p.suffix.lower() == ".tls" for p in files):
            raise FileNotFoundError(
                f"{self.kernel_dir}: servono almeno un .bsp (de440s.bsp) e un .tls (naif0012.tls). "
                "Esegui scripts/fetch_kernels.py")
        with _spice_lock:
            for p in files:
                if str(p) not in _loaded_kernels:
                    sp.furnsh(str(p))
                    _loaded_kernels.append(str(p))
        self.kernels = [p.name for p in files]

        want = orientation or cfg.MOON_ORIENTATION
        if want in ("auto", "spice"):
            try:
                with _spice_lock:
                    sp.pxform("J2000", self.moon_frame, sp.str2et("2026-06-01T00:00:00"))
                self.orientation = f"spice:{self.moon_frame}"
            except Exception as exc:  # frame o PCK mancante
                if want == "spice":
                    raise RuntimeError(f"Frame {self.moon_frame} non disponibile: {exc}") from exc
                self.orientation = "iau2009"
        else:
            self.orientation = "iau2009"
        if self.orientation == "iau2009":
            self.warnings.append(
                "Lunar orientation from the IAU 2009 model (high-accuracy lunar PCK/FK not loaded): "
                "expect surface-position errors of the order of hundreds of metres.")

    @staticmethod
    def _et0(t0: datetime) -> float:
        import spiceypy as sp
        s = t0.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")
        return sp.str2et(s)

    def vectors_body_fixed(self, t0, offsets_s):
        sp = self._sp
        offsets = np.atleast_1d(np.asarray(offsets_s, float))
        with _spice_lock:
            ets = self._et0(t0) + offsets
            sun, _ = sp.spkpos("SUN", ets, "J2000", "LT+S", "MOON")
            earth, _ = sp.spkpos("EARTH", ets, "J2000", "LT+S", "MOON")
            if self.orientation.startswith("spice:"):
                rot = np.array([sp.pxform("J2000", self.moon_frame, float(e)) for e in ets])
            else:
                rot = iau2009_moon_matrix(ets / 86400.0)
        sun, earth = np.atleast_2d(sun), np.atleast_2d(earth)
        return np.einsum("nij,nj->ni", rot, sun), np.einsum("nij,nj->ni", rot, earth)

    def describe(self) -> dict:
        d = super().describe()
        d["kernels"] = self.kernels
        return d


# --------------------------------------------------------------------------- fallback analitico
class AnalyticEphemeris(BaseEphemeris):
    name = "analytic (astropy built-in + IAU 2009)"
    orientation = "iau2009"

    def __init__(self) -> None:
        super().__init__()
        import astropy  # noqa: F401  (fallisce subito se manca)
        self.warnings.append(
            "Low-accuracy analytic ephemeris (development fallback): load SPICE kernels "
            "before using any number in a report.")

    def vectors_body_fixed(self, t0, offsets_s):
        import astropy.units as u
        from astropy.coordinates import get_body, solar_system_ephemeris
        from astropy.time import Time, TimeDelta

        offsets = np.atleast_1d(np.asarray(offsets_s, float))
        t = Time(t0.astimezone(timezone.utc).replace(tzinfo=None), scale="utc") + TimeDelta(offsets, format="sec")
        with solar_system_ephemeris.set("builtin"):
            moon = get_body("moon", t)
            sun = get_body("sun", t)
        r_moon = np.atleast_2d(moon.cartesian.xyz.to_value(u.km).T)     # geocentrico, GCRS ~ ICRF
        r_sun = np.atleast_2d(sun.cartesian.xyz.to_value(u.km).T)
        rot = iau2009_moon_matrix(np.atleast_1d(t.tdb.jd) - 2451545.0)
        return np.einsum("nij,nj->ni", rot, r_sun - r_moon), np.einsum("nij,nj->ni", rot, -r_moon)


def build_ephemeris(kind: str | None = None) -> BaseEphemeris:
    """auto: SPICE se i kernel ci sono, altrimenti il fallback analitico (con warning)."""
    kind = kind or cfg.EPHEMERIS_BACKEND
    if kind == "spice":
        return SpiceEphemeris()
    if kind == "analytic":
        return AnalyticEphemeris()
    try:
        return SpiceEphemeris()
    except (FileNotFoundError, ImportError):
        return AnalyticEphemeris()
