"""Costanti fisiche, soglie dei modelli e percorsi.

Le soglie marcate [euristica] sono scelte di progetto dichiarate, NON valori normativi:
vanno discusse con chi fa l'analisi RF prima di usarle in un report.
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# --- Luna / Sole / Terra ---------------------------------------------------
MOON_RADIUS_M = 1_737_400.0          # sfera di riferimento dei DEM LOLA
SUN_RADIUS_KM = 695_700.0
EARTH_RADIUS_KM = 6_371.0
AU_KM = 149_597_870.7
SOLAR_CONSTANT_W_M2 = 1361.0         # a 1 AU
C_LIGHT_M_S = 299_792_458.0
BOLTZMANN_DBW_HZ_K = -228.6          # 10*log10(k)

# --- Soglie dei modelli -----------------------------------------------------
VISIBLE_MIN_FRACTION = 0.01          # [euristica] frazione minima del disco sopra l'orizzonte
FRESNEL_CLEAR_NU = -0.78             # sotto questo valore ITU-R P.526 da perdita nulla
DIFFRACTION_NU_LIMIT = 2.4           # [euristica] oltre: ombra profonda, knife-edge non affidabile
MAX_TIME_STEPS = 20_000

# --- Percorsi e opzioni (override con variabili d'ambiente) -----------------
KERNEL_DIR = Path(os.getenv("GL_KERNEL_DIR", ROOT / "kernels"))
DEM_DIR = Path(os.getenv("GL_DEM_DIR", ROOT / "data" / "dem"))
SITES_FILE = Path(os.getenv("GL_SITES_FILE", ROOT / "data" / "sites.json"))
ARTEMIS_FILE = Path(os.getenv("GL_ARTEMIS_FILE", ROOT / "data" / "artemis_regions.json"))
EPHEMERIS_BACKEND = os.getenv("GL_EPHEMERIS", "auto")          # auto | spice | analytic
MOON_ORIENTATION = os.getenv("GL_MOON_ORIENTATION", "auto")    # auto | spice | iau2009
# Con i kernel DE440 di NAIF i frame hanno questi nomi (gli alias MOON_ME/MOON_PA NON puntano a DE440):
MOON_FRAME = os.getenv("GL_MOON_FRAME", "MOON_ME_DE440_ME421")
