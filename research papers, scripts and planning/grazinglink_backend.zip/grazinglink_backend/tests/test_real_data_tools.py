"""Script per i dati reali (prepare_lola_dem.py, check_dem.py) su file SINTETICI con le stesse
caratteristiche dei prodotti LOLA: DN int16, SCALING_FACTOR 0.5, OFFSET 1737400, stereografica polare sud."""
import subprocess
import sys
from pathlib import Path

import numpy as np
import pytest

rasterio = pytest.importorskip("rasterio")
from rasterio.crs import CRS  # noqa: E402
from rasterio.transform import from_origin  # noqa: E402
from rasterio.warp import transform as warp_transform  # noqa: E402

from grazinglink.terrain import Dem, GeoTiffDemSource, latlon_to_xy_south, xy_to_latlon_south  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
STERE_SOUTH = CRS.from_string("+proj=stere +lat_0=-90 +lat_ts=-90 +lon_0=0 +x_0=0 +y_0=0 +a=1737400 +b=1737400 +units=m +no_defs")
SPHERE = "+proj=longlat +a=1737400 +b=1737400 +no_defs"
RES, HALF, SITE = 50.0, 12_000.0, (-85.5, 0.0)


def _terrain(x, y):
    lat, lon = xy_to_latlon_south(x, y)
    return 300.0 * ((np.abs(lon) < 2.0) & (lat > -85.45) & (lat < -85.40)) - 1500.0


def _write(path, data, dtype, crs=STERE_SOUTH, scale=None, offset=None, nodata=None):
    mem = Dem.from_function(_terrain, HALF, RES, "m", center_xy=latlon_to_xy_south(*SITE))
    ny, nx = mem.z.shape
    with rasterio.open(path, "w", driver="GTiff", height=ny, width=nx, count=1, dtype=dtype, crs=crs, nodata=nodata,
                       transform=from_origin(mem.x0 - RES / 2, mem.y0 + RES / 2, RES, RES)) as ds:
        ds.write(data(mem.z), 1)
        if scale is not None:
            ds.scales, ds.offsets = (scale,), (offset,)
    return mem


def _run(script, *args):
    return subprocess.run([sys.executable, str(ROOT / "scripts" / script), *map(str, args)], capture_output=True, text=True)


def test_backend_projection_convention_equals_proj_south_polar_stereographic():
    lat, lon = np.array([-85.98, -88.0, -85.5, -89.9]), np.array([-1.67, 30.0, -120.0, 175.0])
    xs, ys = warp_transform(SPHERE, STERE_SOUTH, lon.tolist(), lat.tolist())
    ax, ay = latlon_to_xy_south(lat, lon)
    assert np.allclose(xs, ax, atol=1e-3) and np.allclose(ys, ay, atol=1e-3)


def test_prepare_uses_height_not_radius_and_check_passes(tmp_path):
    src, out = tmp_path / "LDEM_FAKE.tif", tmp_path / "out.tif"
    mem = _write(src, lambda z: np.round(z / 0.5).astype("int16"), "int16", scale=0.5, offset=1737400.0)
    r = _run("prepare_lola_dem.py", src, "-o", out, "--crop", *SITE, 10)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "NON viene sommato" in r.stdout
    with rasterio.open(out) as ds:
        z = ds.read(1)
        assert ds.dtypes[0] == "float32" and ds.crs is not None
    assert 1_000 < np.nanmax(np.abs(z)) < 3_000 and abs(np.nanmin(z) - (-1500.0)) < 1.0       # altezze, non raggi

    c = _run("check_dem.py", out, "--lat", SITE[0], "--lon", SITE[1], "--range-km", 8)
    assert c.returncode == 0, c.stdout + c.stderr
    assert "[PASS] proiezione del file" in c.stdout and "ESITO: nessun FAIL" in c.stdout
    # il punto piu' alto trovato dal check deve stare sulla cresta sintetica (lat -85.45..-85.40, |lon| < 2)
    line = next(l for l in c.stdout.splitlines() if "piu' alto" in l)
    lat = float(line.split("lat ")[1].split(",")[0]); lon = float(line.split("lon ")[1].split(",")[0])
    assert -85.46 < lat < -85.39 and abs(lon) < 2.1


def test_radius_like_file_is_rejected_by_loader_and_check(tmp_path):
    bad = tmp_path / "radius.tif"
    _write(bad, lambda z: (z + 1737400.0).astype("float32"), "float32")
    with pytest.raises(ValueError, match="RAGGIO"):
        GeoTiffDemSource(bad).load(*SITE, 8_000)
    c = _run("check_dem.py", bad, "--lat", SITE[0], "--lon", SITE[1], "--range-km", 8)
    assert c.returncode == 1 and "[FAIL] le quote sembrano il RAGGIO" in c.stdout
    p = _run("prepare_lola_dem.py", bad, "-o", tmp_path / "x.tif", "--scale", 1.0)
    assert p.returncode == 1 and "implausibili" in p.stdout


def test_check_flags_wrong_projection_and_small_edge_distance(tmp_path):
    f = tmp_path / "shifted.tif"
    wrong = CRS.from_string("+proj=stere +lat_0=-90 +lat_ts=-90 +lon_0=45 +x_0=0 +y_0=0 +a=1737400 +b=1737400 +units=m +no_defs")
    _write(f, lambda z: z.astype("float32"), "float32", crs=wrong)       # lon_0 diverso: griglia ruotata di 45 gradi
    c = _run("check_dem.py", f, "--lat", SITE[0], "--lon", SITE[1], "--range-km", 8)
    assert "[FAIL] proiezione diversa" in c.stdout and c.returncode == 1
    g = tmp_path / "ok.tif"
    _write(g, lambda z: z.astype("float32"), "float32")
    c2 = _run("check_dem.py", g, "--lat", SITE[0], "--lon", SITE[1], "--range-km", 60)
    assert "[WARN] il bordo del DEM dista" in c2.stdout
