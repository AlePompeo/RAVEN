"""Test unitari dei motori che non richiedono effemeridi."""
import numpy as np
import pytest

from grazinglink import config as cfg
from grazinglink.horizon import HorizonEngine
from grazinglink.models import MissionScenario, PanelMode, SolarPanel
from grazinglink.rf import classify_path, fresnel_nu, fspl_db, knife_edge_loss_db
from grazinglink.terrain import Dem, latlon_to_xy_south, xy_to_latlon_south
from grazinglink.visibility import disc_visible_fraction, solar_power_w
from grazinglink.windows import complement, extract_windows, next_edge


# ----------------------------------------------------------------------------- RF
def test_fspl_earth_moon_x_band():
    assert fspl_db(384_400e3, 8.4e9) == pytest.approx(222.6, abs=0.1)


def test_knife_edge_known_values():
    assert knife_edge_loss_db(0.0) == pytest.approx(6.0, abs=0.1)           # ~6 dB al bordo
    assert knife_edge_loss_db(1.0) == pytest.approx(13.9, abs=0.1)
    assert knife_edge_loss_db(-1.0) == 0.0 and knife_edge_loss_db(-0.78) == 0.0


def test_fresnel_nu_sign_and_scale():
    # ostacolo 10 m sopra la linea di vista a 1 km, 8.4 GHz: nu = 10*sqrt(2/(0.0357*1000)) ~ 2.37
    assert float(fresnel_nu(10.0, 1000.0, 8.4e9)) == pytest.approx(2.37, abs=0.02)
    assert float(fresnel_nu(-10.0, 1000.0, 8.4e9)) < 0


def test_classify_path_four_states():
    out = classify_path(np.array([-2.0, -0.3, 1.0, 5.0]))
    assert list(out) == ["los_clear", "fresnel_zone_obstructed", "diffracted", "shadowed_beyond_model"]


# ----------------------------------------------------------------------------- finestre
def test_windows_edges_are_refined_and_reasons_kept():
    t = np.arange(0, 3601, 600.0)                       # griglia a 10 min
    true_edges = (1234.0, 2987.0)
    pred = lambda tt: (tt >= true_edges[0]) & (tt < true_edges[1])   # noqa: E731
    mask = pred(t)
    reasons = np.where(mask, "ok", "night")
    (w,) = extract_windows(t, mask, reasons, refine=pred)
    assert w.start_s == pytest.approx(true_edges[0], abs=0.5)
    assert w.end_s == pytest.approx(true_edges[1], abs=0.5)
    assert w.closed_by == "night" and w.opened_by == "transition"
    (g_before, g_after) = complement(t, mask, refine=pred)
    assert g_before.opened_by == "start_of_simulation" and g_after.closed_by == "end_of_simulation"


def test_window_open_at_boundaries():
    t = np.arange(0, 100.0, 10.0)
    (w,) = extract_windows(t, np.ones_like(t, bool))
    assert w.opened_by == "start_of_simulation" and w.closed_by == "end_of_simulation"
    assert next_edge(t, np.ones_like(t, bool)) is None


# ----------------------------------------------------------------------------- proiezione e DEM
def test_projection_roundtrip():
    lat, lon = np.array([-85.0, -89.5, -80.0]), np.array([10.0, -120.0, 175.0])
    lat2, lon2 = xy_to_latlon_south(*latlon_to_xy_south(lat, lon))
    assert np.allclose(lat, lat2) and np.allclose(lon, lon2)
    x, y = latlon_to_xy_south(-85.0, 0.0)               # distanza dal polo ~ 5 gradi di arco
    assert float(np.hypot(x, y)) == pytest.approx(np.radians(5.0) * cfg.MOON_RADIUS_M, rel=0.002)


def test_dem_bilinear_and_nodata():
    z = np.array([[0.0, 10.0], [20.0, 30.0]])
    dem = Dem("t", z, 0.0, 10.0, 10.0)
    assert dem.sample(np.array([5.0]), np.array([5.0]))[0] == pytest.approx(15.0)
    assert np.isnan(dem.sample(np.array([50.0]), np.array([5.0]))[0])


# ----------------------------------------------------------------------------- orizzonte
def test_flat_sphere_horizon_is_the_geometric_dip():
    eng = HorizonEngine()
    p = eng.profile(None, -85.0, 10.0, observer_height_m=2.0, n_az=72, max_range_m=20_000)
    dip = -np.degrees(np.arccos(cfg.MOON_RADIUS_M / (cfg.MOON_RADIUS_M + 2.0)))
    assert np.allclose(p.elev_deg, dip, atol=0.003) and p.sphere_dip_deg == pytest.approx(dip)


def test_wall_horizon_matches_closed_form():
    """Un muro alto H a distanza D verso Nord: l'elevazione deve coincidere con la formula chiusa."""
    D, H, h_obs, res = 10_000.0, 500.0, 2.0, 50.0

    def wall(x, y):
        lat, lon = xy_to_latlon_south(x, y)
        arc = (lat + 85.0) * np.pi / 180.0 * cfg.MOON_RADIUS_M      # distanza lungo il meridiano
        return np.where((np.abs(lon) < 30) & (arc >= D) & (arc < D + 400), H, 0.0)

    dem = Dem.from_function(wall, 40_000, res, center_xy=latlon_to_xy_south(-85.0, 0.0))
    eng = HorizonEngine()
    p = eng.profile(dem, -85.0, 0.0, h_obs, n_az=360, max_range_m=30_000)
    d_first = np.ceil(D / res) * res                    # primo campione dentro il muro
    th, R = d_first / cfg.MOON_RADIUS_M, cfg.MOON_RADIUS_M
    expected = np.degrees(np.arctan2((R + H) * np.cos(th) - (R + h_obs), (R + H) * np.sin(th)))
    assert not p.dem_limited.any()
    assert p.at(0.0) == pytest.approx(expected, abs=0.04)      # verso il muro (Nord, az 0)
    assert p.at(180.0) < 0.0                                   # verso il polo: nessun rilievo
    assert p.at(0.0) > p.at(90.0)


def test_dem_limited_is_flagged():
    dem = Dem.from_function(lambda x, y: 0 * x, 5_000, 50.0, center_xy=latlon_to_xy_south(-89.99, 0.0))
    p = HorizonEngine().profile(dem, -89.99, 0.0, 2.0, n_az=72, max_range_m=40_000)
    assert p.dem_limited.all()


# ----------------------------------------------------------------------------- disco e potenza
class _Flat:
    """Orizzonte piatto a quota data, per testare il disco."""
    def __init__(self, level): self.level = level
    def at(self, az): return np.full_like(np.asarray(az, float), self.level)


def test_disc_fraction_limits_and_half():
    r = np.array([0.27])
    assert disc_visible_fraction(_Flat(0.0), [10.0], [5.0], r)[0] == 1.0
    assert disc_visible_fraction(_Flat(0.0), [10.0], [-5.0], r)[0] == 0.0
    assert disc_visible_fraction(_Flat(0.0), [10.0], [0.0], r)[0] == pytest.approx(0.5, abs=0.03)


def test_solar_power_vertical_tracking_vs_flat_panel_at_low_sun():
    el = np.radians(1.5)
    sun = np.array([[np.cos(el), 0.0, np.sin(el)]])
    d, frac = np.array([1.496e8]), np.array([1.0])
    vertical = solar_power_w(SolarPanel(), sun, d, frac)[0]
    flat = solar_power_w(SolarPanel(mode=PanelMode.fixed, tilt_deg=0.0), sun, d, frac)[0]
    assert vertical == pytest.approx(2.0 * 0.28 * 1361.0 * np.cos(el), rel=0.01)
    assert vertical > 20 * flat                                  # Sole a 1.5 gradi: pannello orizzontale quasi inutile


def test_tilt_without_mode_means_fixed_panel():
    p = SolarPanel(tiltDegrees=15)
    assert p.mode == PanelMode.fixed and p.tilt_deg == 15


def test_scenario_validation_and_aliases():
    sc = MissionScenario.model_validate({"id": "x", "latitude": -85, "longitude": 190, "startTime": "2027-04-07T00:00:00Z",
                                         "durationHours": 48, "timeStepMinutes": 10, "observerHeightMeters": 2.0})
    assert sc.longitude == pytest.approx(-170.0) and sc.n_steps == 289
    with pytest.raises(ValueError):
        MissionScenario.model_validate({"id": "x", "latitude": -85, "longitude": 0, "startTime": "2027-04-07T00:00:00Z",
                                        "durationHours": 24 * 365, "timeStepMinutes": 1})
    with pytest.raises(ValueError):                              # parametro scritto male = errore, non ignorato
        MissionScenario.model_validate({"id": "x", "latitude": -85, "longitude": 0, "startTime": "2027-04-07T00:00:00Z",
                                        "durationHour": 24})
