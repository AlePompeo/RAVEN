"""Catalogo Artemis, script delle coordinate, finestre di permanenza e API."""
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pytest

from grazinglink import config as cfg
from grazinglink.artemis import load_artemis, region_status, regions_with_status, set_region_coordinates
from grazinglink.mission import MissionEngine
from grazinglink.models import MissionScenario
from grazinglink.terrain import Dem, DemCatalog, MemoryDemSource, latlon_to_xy_south

ROOT = Path(__file__).resolve().parent.parent
NINE_2024 = {"Peak near Cabeus B", "Haworth", "Malapert Massif", "Mons Mouton Plateau", "Mons Mouton",
             "Nobile Rim 1", "Nobile Rim 2", "de Gerlache Rim 2", "Slater Plain"}
THIRTEEN_2022 = {"Faustini Rim A", "Peak Near Shackleton", "Connecting Ridge", "Connecting Ridge Extension",
                 "de Gerlache Rim 1", "de Gerlache Rim 2", "de Gerlache-Kocher Massif", "Haworth", "Malapert Massif",
                 "Leibnitz Beta Plateau", "Nobile Rim 1", "Nobile Rim 2", "Amundsen Rim"}


@pytest.fixture()
def art_file(tmp_path):
    p = tmp_path / "artemis.json"
    shutil.copy(cfg.ARTEMIS_FILE, p)
    return p


# ----------------------------------------------------------------------------- catalogo
def test_catalogue_matches_nasa_lists_and_invents_no_coordinates():
    data = load_artemis()
    regs = data["regions"]
    assert {r["name"] for r in regs if r["in_2022_list_of_13"]} == THIRTEEN_2022
    assert {r["name"] for r in regs if r["in_2024_list_of_9"]} == NINE_2024
    assert len(regs) == 17 and len({r["id"] for r in regs}) == 17
    assert all(r["latitude"] is None and r["longitude"] is None and not r["coordinates_verified"] for r in regs)
    assert data["meta"]["reference_stay_hours"] == 156 and "Artemis IV" in data["meta"]["program_status"]["summary"]


def test_set_coordinates_validates_and_status_goes_needs_coords_to_ready(art_file):
    with pytest.raises(ValueError):
        set_region_coordinates("haworth", -60.0, 0.0, "x", path=art_file)            # fuori dai 6 gradi dal polo
    with pytest.raises(ValueError):
        set_region_coordinates("haworth", -87.0, 0.0, "  ", path=art_file)           # senza fonte
    with pytest.raises(KeyError):
        set_region_coordinates("atlantide", -87.0, 0.0, "x", path=art_file)
    assert regions_with_status(None, art_file)["regions"][0]["status"] == "needs_coordinates"

    r = set_region_coordinates("haworth", -87.45, 190.0, "test", verified=True, path=art_file)
    assert r["longitude"] == pytest.approx(-170.0) and r["coordinates_verified"] is True
    assert region_status(r, DemCatalog())["status"] == "no_dem"
    dem = Dem.from_function(lambda x, y: 0 * x, 5_000, 50.0, "HAW", center_xy=latlon_to_xy_south(-87.45, -170.0))
    st = region_status(r, DemCatalog([MemoryDemSource(dem)]))
    assert st["status"] == "ready" and st["dems"][0]["id"] == "HAW"


def test_cli_list_set_and_reject(art_file):
    env = {"GL_ARTEMIS_FILE": str(art_file), "PATH": ""}
    run = lambda *a: subprocess.run([sys.executable, str(ROOT / "scripts" / "add_artemis_site.py"), *a],  # noqa: E731
                                    capture_output=True, text=True, env={**env, "SYSTEMROOT": ""})
    out = run("--list")
    assert out.returncode == 0 and "malapert-massif" in out.stdout and "coordinate mancanti" in out.stdout
    ok = run("--region", "malapert-massif", "--lat", "-86.0", "--lon", "0.0", "--source", "test", "--verified")
    assert ok.returncode == 0 and "Salvato malapert-massif" in ok.stdout
    assert json.loads(art_file.read_text())["regions"][8]["latitude"] == -86.0
    bad = run("--region", "malapert-massif", "--lat", "-30", "--lon", "0", "--source", "x")
    assert bad.returncode == 1 and "ERRORE" in bad.stdout
    assert run("--region", "malapert-massif").returncode == 1                       # niente coordinate: errore


def test_cli_from_dem_uses_dem_centre(art_file, tmp_path):
    rasterio = pytest.importorskip("rasterio")
    from rasterio.crs import CRS
    from rasterio.transform import from_origin
    c = latlon_to_xy_south(-85.5, 0.0)
    mem = Dem.from_function(lambda x, y: 0 * x, 6_000, 50.0, "m", center_xy=c)
    f = tmp_path / "patch.tif"
    crs = CRS.from_string("+proj=stere +lat_0=-90 +lat_ts=-90 +lon_0=0 +a=1737400 +b=1737400 +units=m +no_defs")
    with rasterio.open(f, "w", driver="GTiff", height=mem.z.shape[0], width=mem.z.shape[1], count=1, dtype="float32",
                       crs=crs, transform=from_origin(mem.x0 - 25, mem.y0 + 25, 50.0, 50.0)) as ds:
        ds.write(mem.z.astype("float32"), 1)
    r = subprocess.run([sys.executable, str(ROOT / "scripts" / "add_artemis_site.py"), "--region", "nobile-rim-1",
                        "--from-dem", str(f), "--source", "centro DEM"], capture_output=True, text=True,
                       env={"GL_ARTEMIS_FILE": str(art_file), "PATH": "", "SYSTEMROOT": ""})
    assert r.returncode == 0 and "da verificare" in r.stdout
    reg = next(x for x in json.loads(art_file.read_text())["regions"] if x["id"] == "nobile-rim-1")
    assert reg["latitude"] == pytest.approx(-85.5, abs=0.01) and abs(reg["longitude"]) < 0.01


# ----------------------------------------------------------------------------- finestre di permanenza
@pytest.fixture(scope="module")
def stay(ephem_any):
    eng = MissionEngine(ephem_any, DemCatalog())
    sc = MissionScenario(id="p", latitude=-89.9, longitude=0.0, startTime=datetime(2027, 1, 1, tzinfo=timezone.utc),
                         durationHours=1, observerHeightMeters=2.0)
    return eng, sc, eng.stay_windows(sc, n_days=200, stay_hours=156, stride_hours=24, step_min=60)


def test_stay_windows_are_internally_consistent(stay):
    _, _, r = stay
    n = r["summary"]["n_starts"]
    assert n == 201 and len(r["start"]) == len(r["ok"]) == len(r["sunlit_percent"]) == n
    ok = np.array(r["ok"])
    assert 0 < ok.sum() < n                                              # ci sono date buone e date cattive
    assert np.array_equal(ok, np.array(r["longest_dark_h"]) == 0.0)      # criterio = nessun buio in tutta la permanenza
    assert (np.array(r["sunlit_percent"])[ok] == 100.0).all()
    assert sum(g["n_starts"] for g in r["summary"]["ok_start_ranges"]) == ok.sum()
    assert any("No DEM" in w for w in r["provenance"]["warnings"])


def test_stay_windows_agree_with_a_direct_run(stay):
    eng, sc, r = stay
    ok = np.array(r["ok"])
    good, bad = int(np.flatnonzero(ok)[0]), int(np.flatnonzero(~ok)[0])
    for idx, expect_full in ((good, True), (bad, False)):
        start = datetime.fromisoformat(r["start"][idx].replace("Z", "+00:00"))
        run = eng.run(sc.model_copy(update={"start_time": start, "duration_hours": 156.0, "time_step_minutes": 60.0}),
                      refine=False)
        assert (run.summary["sunlit_percent"] == 100.0) == expect_full


def test_stay_windows_extra_criteria_only_restrict(stay):
    eng, sc, r = stay
    r2 = eng.stay_windows(sc, 200, 156, 24, 60, max_earth_blackout_h=0.0)
    assert r2["summary"]["n_ok"] <= r["summary"]["n_ok"]
    assert all(b == 0.0 for b, o in zip(r2["longest_earth_blackout_h"], r2["ok"]) if o)
    r3 = eng.stay_windows(sc, 200, 156, 24, 60, continuous_sunlight=False)
    assert r3["summary"]["n_ok"] == 201                                  # senza criteri tutte le date sono "ok"
    with pytest.raises(ValueError):
        eng.stay_windows(sc, 400, 156, 6, 5)                             # troppi campioni


# ----------------------------------------------------------------------------- API
def test_api_artemis_and_stay_windows(ephem_any):
    from fastapi.testclient import TestClient

    from grazinglink.api import create_app
    c = TestClient(create_app(MissionEngine(ephem_any, DemCatalog())))
    j = c.get("/artemis/regions").json()
    assert len(j["regions"]) == 17 and {r["status"] for r in j["regions"]} == {"needs_coordinates"}
    assert j["meta"]["reference_stay_hours"] == 156

    sc = {"id": "p", "latitude": -89.9, "longitude": 0.0, "startTime": "2027-01-01T00:00:00Z", "durationHours": 1}
    r = c.post("/stay-windows", json={"scenario": sc, "n_days": 30, "stride_hours": 24, "step_minutes": 60})
    assert r.status_code == 200 and r.json()["summary"]["n_starts"] == 31 and r.json()["stay_hours"] == 156.0
    assert c.post("/stay-windows", json={"scenario": sc, "n_days": 400, "stride_hours": 1, "step_minutes": 1}).status_code == 422
    assert c.post("/stay-windows", json={"scenario": sc, "stay_hours": 0}).status_code == 422
