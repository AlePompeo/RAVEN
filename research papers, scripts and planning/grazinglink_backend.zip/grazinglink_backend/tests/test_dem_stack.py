"""DEM multi-livello: un DEM fine regionale (5 m) sopra uno polare piu' grosso."""
import numpy as np
import pytest

from grazinglink import config as cfg
from grazinglink.horizon import HorizonEngine
from grazinglink.terrain import Dem, DemCatalog, DemStack, MemoryDemSource, latlon_to_xy_south, xy_to_latlon_south

SITE = (-85.5, 0.0)
C = latlon_to_xy_south(*SITE)


def _far_ridge(x, y):
    """Cresta di 300 m a ~10 km a Nord del sito."""
    lat, lon = xy_to_latlon_south(x, y)
    arc = (lat + 85.5) * np.pi / 180.0 * cfg.MOON_RADIUS_M
    return np.where((np.abs(lon) < 40) & (arc >= 10_000) & (arc < 10_600), 300.0, 0.0)


@pytest.fixture()
def layers():
    fine = Dem.from_function(lambda x, y: 0 * x + 7.0, 1_500, 5.0, "FINE5m", center_xy=C)
    coarse = Dem.from_function(_far_ridge, 40_000, 100.0, "COARSE100m", center_xy=C)
    return fine, coarse


def test_stack_prefers_fine_inside_and_falls_back_outside(layers):
    fine, coarse = layers
    st = DemStack([fine, coarse])
    inside = st.sample(np.array([C[0]]), np.array([C[1]]))[0]
    outside = st.sample(np.array([C[0]]), np.array([C[1] + 10_300.0]))[0]       # sulla cresta, fuori dal DEM fine
    nowhere = st.sample(np.array([C[0]]), np.array([C[1] + 90_000.0]))[0]
    assert inside == pytest.approx(7.0) and outside == pytest.approx(300.0) and np.isnan(nowhere)
    assert st.res_m == 5.0 and st.dem_id == "FINE5m + COARSE100m"


def test_horizon_sees_far_ridge_only_with_the_stack(layers):
    fine, coarse = layers
    hz, args = HorizonEngine(), (SITE[0], SITE[1], 2.0, 72, 20_000)
    only_fine = hz.profile(fine, *args)
    stacked = hz.profile(DemStack([fine, coarse]), *args)
    assert only_fine.dem_limited.all()                              # il DEM fine finisce a 1.5 km
    assert only_fine.at(0.0) < 0.0                                  # senza fallback la cresta non si vede
    assert stacked.at(0.0) > 0.5                                    # con lo stack si': ~300 m a 10 km
    assert stacked.dem_res_m == 5.0 and stacked.dem_id == "FINE5m + COARSE100m"


def test_catalog_returns_a_stack_when_several_dems_cover_the_site(layers):
    fine, coarse = layers
    cat = DemCatalog([MemoryDemSource(coarse), MemoryDemSource(fine)])
    dem = cat.load(*SITE, 20_000)
    assert isinstance(dem, DemStack) and [d.dem_id for d in dem.layers] == ["FINE5m", "COARSE100m"]   # fine -> grosso
    assert isinstance(DemCatalog([MemoryDemSource(coarse)]).load(*SITE, 20_000), Dem)


def test_two_zone_spacing_keeps_fine_step_near_and_respects_step_budget(layers):
    fine, _ = layers
    hz = HorizonEngine()
    d = hz._distances(fine, 60_000.0)
    assert d[0] == 5.0 and np.allclose(np.diff(d[:400]), 5.0)       # 5 m nei primi 2 km
    assert d.size <= hz.max_steps and np.all(np.diff(d) > 0) and d[-1] == pytest.approx(60_000.0, rel=0.01)
    assert 10.0 < np.diff(d)[-1] < 25.0                              # oltre, passo allargato (~16 m)


def test_engine_provenance_lists_every_dem_layer(layers, ephem_any):
    from datetime import datetime, timezone

    from grazinglink.mission import MissionEngine
    from grazinglink.models import MissionScenario
    fine, coarse = layers
    eng = MissionEngine(ephem_any, DemCatalog([MemoryDemSource(fine), MemoryDemSource(coarse)]))
    r = eng.run(MissionScenario(id="s", latitude=SITE[0], longitude=SITE[1], startTime=datetime(2027, 4, 7, tzinfo=timezone.utc),
                                durationHours=24, timeStepMinutes=60, horizonRangeKm=20), refine=False)
    dem = r.provenance["dem"]
    assert [l["id"] for l in dem["layers"]] == ["FINE5m", "COARSE100m"] and dem["resolution_m"] == 5.0
