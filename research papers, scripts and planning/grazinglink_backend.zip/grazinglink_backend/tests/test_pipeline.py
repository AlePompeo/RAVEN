"""Test end-to-end. Usano SPICE se i kernel ci sono (GL_TEST_KERNELS o ./kernels), altrimenti il
fallback analitico; saltano se manca anche astropy. Il terreno e' SINTETICO: i test verificano
invarianti fisici e coerenza interna, non i valori di un sito lunare reale."""
import os
from datetime import datetime, timezone

import numpy as np
import pytest

from grazinglink import config as cfg
from grazinglink.compare import compare, shifted
from grazinglink.ephemeris import AnalyticEphemeris, SpiceEphemeris, build_ephemeris
from grazinglink.mission import MissionEngine
from grazinglink.models import Antenna, MissionScenario
from grazinglink.terrain import Dem, DemCatalog, MemoryDemSource, latlon_to_xy_south, xy_to_latlon_south
from grazinglink.windows import extract_windows

T0 = datetime(2027, 4, 7, tzinfo=timezone.utc)


def _make_ephemeris():
    kdir = os.getenv("GL_TEST_KERNELS")
    try:
        return SpiceEphemeris(kernel_dir=kdir) if kdir else build_ephemeris()
    except Exception as exc:  # nessun backend disponibile
        pytest.skip(f"nessun backend di effemeridi disponibile: {exc}")


@pytest.fixture(scope="module")
def ephem():
    return _make_ephemeris()


def _ridge(x, y):
    lat, lon = xy_to_latlon_south(x, y)
    return 350.0 * ((np.abs(lon) < 1.0) & (lat > -85.4) & (lat < -85.3))


@pytest.fixture(scope="module")
def engine(ephem):
    dem = Dem.from_function(_ridge, 40_000, 40.0, "SYN", center_xy=latlon_to_xy_south(-85.5, 0.0))
    return MissionEngine(ephem, DemCatalog([MemoryDemSource(dem)]))


def _scenario(**kw):
    base = dict(id="A", latitude=-85.5, longitude=0.0, startTime=T0, durationHours=30 * 24,
                timeStepMinutes=30, antenna=Antenna())
    base.update(kw)
    return MissionScenario(**base)


# ----------------------------------------------------------------------------- geometria
def test_subsolar_point_matches_team_app(ephem):
    """La app del team mostra per 2027-04-07 00:00 UTC: subsolare lat 1.30 N, lon 174.61 E."""
    p = ephem.sub_points(T0, [0.0])
    assert p["subsolar_lat_deg"][0] == pytest.approx(1.30, abs=0.03)
    assert p["subsolar_lon_deg"][0] == pytest.approx(174.61, abs=0.03)


def test_libration_and_solar_declination_bounds(ephem):
    p = ephem.sub_points(T0, np.arange(0, 30 * 86400, 3600.0))
    assert np.abs(p["subearth_lat_deg"]).max() < 6.9 and np.abs(p["subearth_lon_deg"]).max() < 8.2
    assert np.abs(p["subsolar_lat_deg"]).max() < 1.6                     # inclinazione dell'asse lunare ~1.54 gradi


def test_polar_site_sun_never_rises_above_about_two_degrees(ephem):
    sky = ephem.sky(T0, np.arange(0, 30 * 86400, 3600.0), -89.9, 0.0, 2.0)
    el = np.degrees(np.arcsin(sky.sun_enu[:, 2]))
    assert el.max() < 1.8 and el.min() > -1.8
    assert sky.sun_radius_deg.mean() == pytest.approx(0.265, abs=0.01)
    assert 0.88 < sky.earth_radius_deg.min() and sky.earth_radius_deg.max() < 1.05


def test_analytic_fallback_agrees_with_main_backend(ephem):
    pytest.importorskip("astropy")
    if isinstance(ephem, AnalyticEphemeris):
        pytest.skip("stesso backend")
    off = np.arange(0, 10 * 86400, 3600.0)
    a, b = ephem.sky(T0, off, -85.5, 0.0, 2.0), AnalyticEphemeris().sky(T0, off, -85.5, 0.0, 2.0)
    for va, vb in ((a.sun_enu, b.sun_enu), (a.earth_enu, b.earth_enu)):
        ang = np.degrees(np.arccos(np.clip((va * vb).sum(axis=1), -1, 1)))
        assert ang.max() < 0.02                                          # gradi


# ----------------------------------------------------------------------------- pipeline
@pytest.fixture(scope="module")
def result(engine):
    return engine.run(_scenario())


def test_windows_are_consistent_with_grid(result):
    S, t = result.samples, result.t_s
    step = result.scenario.time_step_minutes * 60.0
    for dom, key in (("sun", "sunlit"), ("earth", "earth_visible"), ("rf", "rf_ok")):
        ws = result.windows[dom]
        in_win = np.zeros(t.size, bool)
        for w in ws:
            in_win |= (t >= w.start_s - 1e-6) & (t <= w.end_s + 1e-6)
            assert w.start_s <= w.end_s
        # ogni campione "vero" cade in una finestra; i bordi raffinati stanno entro un passo dai campioni
        assert in_win[S[key]].all()
        assert (in_win & ~S[key]).sum() <= 2 * len(ws)                    # al piu' i campioni di bordo
        total = sum(w.duration_s for w in ws)
        assert total == pytest.approx(S[key].sum() * step, abs=step * (len(ws) + 1))


def test_gaps_and_windows_partition_the_time(result):
    total = result.t_s[-1] - result.t_s[0]
    for dom in ("sun", "earth", "rf"):
        s = sum(w.duration_s for w in result.windows[dom]) + sum(g.duration_s for g in result.gaps[dom])
        assert s == pytest.approx(total, rel=1e-6)


def test_closing_reasons_are_meaningful(result):
    reasons = {w.closed_by for w in result.windows["sun"] + result.windows["earth"]}
    assert reasons <= {"terrain_occultation", "below_lunar_horizon", "end_of_simulation"}
    assert {w.closed_by for w in result.windows["rf"]} <= {"shadowed_beyond_model", "margin_below_threshold",
                                                            "end_of_simulation"}


def test_terrain_reduces_visibility_versus_bare_sphere(ephem, engine):
    bare = MissionEngine(ephem, DemCatalog())                             # nessun DEM: orizzonte = sola curvatura
    with_dem, no_dem = engine.run(_scenario(antenna=None)), bare.run(_scenario(antenna=None))
    assert no_dem.summary["earth_visible_percent"] > with_dem.summary["earth_visible_percent"]
    assert any("No DEM" in w for w in no_dem.provenance["warnings"])


def test_rf_window_is_not_a_copy_of_geometric_visibility(engine):
    """Con una soglia di margine alta, il link chiude solo in parte della visibilita' geometrica."""
    first = engine.run(_scenario(), refine=False)
    vis = first.samples["earth_visible"] & (first.samples["path_condition"] == "los_clear")
    thr = float(np.median(first.samples["link_margin_db"][vis]))
    r = engine.run(_scenario(rfThresholdDb=thr))
    assert 0 < r.summary["rf_available_percent"] < r.summary["earth_visible_percent"]


def test_diffraction_lets_link_exist_below_geometric_visibility(result):
    """Terra sotto l'orizzonte locale ma link sopra soglia: esiste solo grazie alla diffrazione (da dichiarare)."""
    S = result.samples
    hidden_but_ok = ~S["earth_visible"] & S["rf_ok"]
    if hidden_but_ok.any():
        assert np.isin(S["path_condition"][hidden_but_ok], ["fresnel_zone_obstructed", "diffracted"]).all()
    assert (S["diffraction_loss_db"][S["path_condition"] == "los_clear"] == 0).all()


def test_margin_matches_hand_calculation(engine):
    """C/N0 = EIRP + G/T - L + 228.6 con valori di default e Terra in vista libera."""
    r = engine.run(_scenario(durationHours=48), refine=False)
    ok = r.samples["path_condition"] == "los_clear"
    assert ok.any()
    d = r.samples["earth_distance_km"][ok] * 1e3
    fspl = 20 * np.log10(4 * np.pi * d * 8.4e9 / cfg.C_LIGHT_M_S)
    expected = (10 + 8 - 1) + 50 - (fspl + 0.5 + 1.0) + 228.6 - 10 * np.log10(30_000) - 2.5
    assert np.allclose(r.samples["link_margin_db"][ok], expected, atol=1e-6)


def test_sun_power_zero_in_shadow_and_positive_in_light(result):
    S = result.samples
    assert (S["solar_power_w"][~S["sunlit"]] == 0).all()
    assert (S["solar_power_w"][S["sunlit"]] > 0).all()
    assert result.summary["solar_energy_wh"] > 0


def test_countdown_agrees_with_full_run(engine, result):
    cd = engine.countdown(_scenario(), max_days=30)
    first_sun = result.windows["sun"][0]            # al via e' buio: il primo evento e' l'alba
    assert cd["sun"]["state"] == "dark" and cd["sun"]["next_event"] == "sunrise"
    assert cd["sun"]["in_seconds"] == pytest.approx(first_sun.start_s, abs=120)
    assert cd["earth"]["next_event"] in ("earthrise", "earthset")


def test_countdown_reports_no_change_instead_of_inventing(engine):
    cd = engine.countdown(_scenario(), max_days=2)
    assert cd["sun"]["in_seconds"] is None and "no change" in cd["sun"]["note"]


def test_sweep_shapes_and_bounds(engine):
    out = engine.sweep(_scenario(), n_days=20, stride_days=1.5)
    for k in ("sunlit_percent", "earth_visible_percent", "sun_and_earth_percent"):
        assert len(out[k]) == 20 and all(0 <= v <= 100 for v in out[k])
    with pytest.raises(ValueError):
        engine.sweep(_scenario(), n_days=370, step_min=1.0)


def test_compare_same_site_shifted_dates(engine):
    a = _scenario(durationHours=72)
    res = [engine.run(a), engine.run(shifted(a, 14))]
    cmp = compare(res)
    assert set(cmp["changed_parameters"]) == {"start_time"}
    assert cmp["scenarios"] == ["A", "A+14d"]
    assert all("best" in m for m in cmp["metrics"]) and "score" not in str(cmp.keys()).lower()
    with pytest.raises(ValueError):
        compare([engine.run(a), engine.run(_scenario(id="B", durationHours=48))])


def test_provenance_declares_assumptions(result):
    prov = result.provenance
    assert prov["dem"]["id"] == "SYN" and prov["ephemeris"]["backend"]
    assert any("illustrative" in w for w in prov["warnings"])
    assert any("uniform discs" in w for w in prov["warnings"])


# ----------------------------------------------------------------------------- API
def test_api_end_to_end(engine):
    from fastapi.testclient import TestClient
    from grazinglink.api import create_app
    c = TestClient(create_app(engine))
    body = {"id": "A", "latitude": -85.5, "longitude": 0.0, "startTime": "2027-04-07T00:00:00Z",
            "durationHours": 72, "timeStepMinutes": 30, "antenna": {"frequencyHz": 8.4e9, "txPowerW": 10}}

    assert c.get("/health").json()["status"] == "ok"
    r = c.post("/simulate?decimate=2", json=body)
    assert r.status_code == 200
    j = r.json()
    n = len(j["series"]["time"])
    assert n == len(j["series"]["sun_el_deg"]) == len(j["series"]["link_margin_db"]) and n < 145
    assert set(j["windows"]) == {"sun", "earth", "rf"} and j["provenance"]["warnings"]
    assert len(j["horizon"]["az_deg"]) == 360

    assert c.post("/simulate", json={**body, "durationHour": 1}).status_code == 422       # chiave sconosciuta
    assert c.post("/simulate", json={**body, "latitude": -95}).status_code == 422

    r = c.post("/compare/shift", json={"scenario": body, "shift_days": [14]})
    assert r.status_code == 200 and r.json()["scenarios"] == ["A", "A+14d"]
    r = c.post("/compare", json={"scenarios": [body, {**body, "id": "B", "latitude": -85.45}]})
    assert r.status_code == 200 and "changed_parameters" in r.json()
    r = c.post("/compare", json={"scenarios": [body, {**body, "id": "B", "durationHours": 24}]})
    assert r.status_code == 422                                                           # confronto non valido

    assert c.post("/horizon", json={"latitude": -85.5, "longitude": 0.0}).json()["max_range_km"] == 60.0
    cd = c.post("/countdown", json={"scenario": body, "max_days": 30}).json()
    assert cd["sun"]["state"] in ("sunlit", "dark") and "earth" in cd
    sw = c.post("/sweep", json={"scenarios": [body], "n_days": 5}).json()
    assert len(sw["sites"][0]["sunlit_percent"]) == 5
    assert isinstance(c.get("/sites").json(), list)
