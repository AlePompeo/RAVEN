"""Il lettore GeoTIFF su un file scritto qui (formato come i prodotti LOLA: int16 con fattore di scala,
nodata, stereografica polare sud). NON sostituisce la prova su un DEM LOLA vero."""
import numpy as np
import pytest

rasterio = pytest.importorskip("rasterio")
from rasterio.transform import from_origin  # noqa: E402

from grazinglink.horizon import HorizonEngine  # noqa: E402
from grazinglink.terrain import (Dem, DemCatalog, GeoTiffDemSource, MemoryDemSource,  # noqa: E402
                                 latlon_to_xy_south, xy_to_latlon_south)

RES, HALF = 50.0, 12_000.0
CENTRE = latlon_to_xy_south(-85.5, 0.0)


def _terrain(x, y):
    lat, lon = xy_to_latlon_south(x, y)
    return 300.0 * ((np.abs(lon) < 2.0) & (lat > -85.45) & (lat < -85.40))


@pytest.fixture()
def tif(tmp_path):
    mem = Dem.from_function(_terrain, HALF, RES, "mem", center_xy=CENTRE)
    ny, nx = mem.z.shape
    raw = np.round(mem.z / 0.5).astype("int16")             # fattore di scala 0.5 m, come gli LDEM
    raw[:5, :5] = -32768                                    # una zona senza dato
    path = tmp_path / "LDEM_test.tif"
    tf = from_origin(mem.x0 - RES / 2, mem.y0 + RES / 2, RES, RES)     # angolo alto-sinistra del pixel [0,0]
    with rasterio.open(path, "w", driver="GTiff", height=ny, width=nx, count=1, dtype="int16",
                       transform=tf, nodata=-32768) as ds:
        ds.write(raw, 1)
    return path, mem


def test_geotiff_matches_memory_dem(tif):
    path, mem = tif
    src = GeoTiffDemSource(path, scale=0.5)
    assert src.res_m == RES and src.covers(-85.5, 0.0) and not src.covers(-80.0, 0.0)
    dem = src.load(-85.5, 0.0, 8_000)
    x, y = latlon_to_xy_south(np.array([-85.5, -85.42, -85.38]), np.array([0.0, 0.5, 1.0]))
    assert np.allclose(dem.sample(x, y), mem.sample(x, y), atol=0.5)       # stesso terreno, entro la quantizzazione
    full = src.load(-85.5, 0.0, 13_000)                                    # finestra che include l'angolo senza dato
    assert np.isnan(full.z[:5, :5]).all() and not np.isnan(full.z[10:, 10:]).any()   # nodata -> NaN


def test_horizon_from_geotiff_equals_horizon_from_memory(tif):
    path, mem = tif
    hz = HorizonEngine()
    a = hz.profile(GeoTiffDemSource(path, scale=0.5).load(-85.5, 0.0, 8_000), -85.5, 0.0, 2.0, 180, 8_000)
    b = hz.profile(mem, -85.5, 0.0, 2.0, 180, 8_000)
    assert np.allclose(a.elev_deg, b.elev_deg, atol=0.02)
    assert a.elev_deg.max() > 1.0                                          # il rilievo e' visto


def test_catalog_picks_finest_dem_that_covers_site(tif):
    path, mem = tif
    coarse = Dem.from_function(_terrain, 20_000, 200.0, "coarse", center_xy=CENTRE)
    cat = DemCatalog([MemoryDemSource(coarse), GeoTiffDemSource(path, scale=0.5)])
    assert cat.find(-85.5, 0.0).dem_id == "LDEM_test"
    assert cat.find(-85.5, 90.0) is None
