"""Fixture condivise. Backend di effemeridi: SPICE se i kernel ci sono (GL_TEST_KERNELS o ./kernels),
altrimenti il fallback analitico; i test saltano se non c'e' nessuno dei due."""
import os

import pytest

from grazinglink.ephemeris import SpiceEphemeris, build_ephemeris


@pytest.fixture(scope="session")
def ephem_any():
    kdir = os.getenv("GL_TEST_KERNELS")
    try:
        return SpiceEphemeris(kernel_dir=kdir) if kdir else build_ephemeris()
    except Exception as exc:
        pytest.skip(f"nessun backend di effemeridi disponibile: {exc}")
