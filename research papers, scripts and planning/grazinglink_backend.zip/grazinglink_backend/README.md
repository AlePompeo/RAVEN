# GrazingLink — Mission Planning backend

Un solo motore scientifico (Python), nessuna logica nel frontend. Per un sito e un intervallo di date calcola:
posizione di Sole e Terra rispetto all'orizzonte locale (da DEM), illuminazione, visibilità della Terra,
potenza solare, link budget RF con diffrazione, finestre temporali, conto alla rovescia e confronto A/B.

```
grazinglink/
  ephemeris.py   SPICE (reale) + fallback analitico, rotazione lunare, frame locale Est/Nord/Su
  terrain.py     DEM (GeoTIFF LOLA o in memoria), proiezione polare stereografica
  horizon.py     Horizon Engine: profilo dell'orizzonte con curvatura lunare e altezza del mast
  visibility.py  disco di Sole/Terra sopra l'orizzonte, potenza solare (cos dell'incidenza)
  rf.py          FSPL, diffrazione knife-edge ITU-R P.526, link budget, margine, bitrate massimo
  windows.py     finestre, interruzioni, motivo di chiusura, raffinamento dei bordi per bisezione
  mission.py     MissionEngine: orchestra tutto; riepilogo, conto alla rovescia, sweep, finestre di permanenza
  compare.py     confronto A/B (niente punteggio unico) e "stesso sito, data spostata"
  artemis.py     catalogo delle regioni candidate Artemis (data/artemis_regions.json)
  api.py         FastAPI
```

## Avvio rapido

```bash
pip install -r requirements.txt
python scripts/fetch_kernels.py          # kernel SPICE in ./kernels (se un URL NAIF cambia, vedi lo script)
python -m pytest -q                      # 53 test
python -m examples.demo                  # demo con terreno SINTETICO
uvicorn grazinglink.api:app --reload     # documentazione interattiva su http://127.0.0.1:8000/docs
```

Senza kernel parte comunque con un fallback analitico (astropy) e lo **dichiara** in `provenance.warnings`:
va bene per sviluppare, non per un risultato da mostrare come tale.

## Dati

* **Kernel**: `naif0012.tls`, `de440s.bsp`, `moon_pa_de440_*.bpc`, `moon_de440_*.tf`. Con DE440 i frame si chiamano
  `MOON_ME_DE440_ME421` / `MOON_PA_DE440` (gli alias `MOON_ME`/`MOON_PA` non puntano a DE440). Senza PCK/FK lunari
  il motore usa la rotazione IAU 2009 e lo dichiara.
* **DEM**: GeoTIFF LOLA in `data/dem/` (proiezione stereografica polare sud, quote in metri sulla sfera di 1737.4 km,
  `pip install rasterio`). Se più DEM coprono il sito li **sovrappone** (fine → grosso): il dettaglio a 5 m dove c'è,
  il DEM polare a 20-40 m fuori dal bordo, la sfera solo dove non c'è nessun dato (segnalato in `dem_limited`). Senza DEM l'orizzonte è la sola
  sfera e il risultato è ottimistico (warning). **Verificate proiezione e metadati del vostro file** (vedi `terrain.py`).
* **Siti**: `data/sites.json` è un esempio con coordinate NON verificate: sostituitelo col vostro catalogo.

## Endpoint principali

| Metodo | Percorso | Cosa fa |
|---|---|---|
| POST | `/simulate` | scenario → serie temporali, finestre, interruzioni, riepilogo, provenienza |
| POST | `/compare` | 2–6 scenari → metriche affiancate, parametri che cambiano, migliore per metrica |
| POST | `/compare/shift` | stesso sito con la data spostata di N giorni (lancio che slitta) |
| POST | `/countdown` | tempo al prossimo tramonto/alba e Earthset/Earthrise (cerca fino a 120 giorni) |
| POST | `/sweep` | % di luce e di Terra visibile giorno per giorno, per più siti (heatmap) |
| POST | `/horizon` | profilo dell'orizzonte per lat/lon/altezza |
| POST | `/stay-windows` | per ogni data di arrivo, una permanenza di N ore (default 156 = 6,5 giorni): luce continua, blackout Terra |
| GET | `/artemis/regions` | regioni candidate Artemis con stato (coordinate / DEM) |
| GET | `/sites`, `/health` | catalogo siti; backend effemeridi e DEM caricati |

Esempio (compatibile con il JSON del documento di progetto, alias camelCase accettati):

```json
{"id": "A", "latitude": -85.5, "longitude": 0.0, "startTime": "2027-04-07T00:00:00Z",
 "durationHours": 720, "timeStepMinutes": 30, "observerHeightMeters": 2.0,
 "solarPanel": {"areaM2": 2.0, "efficiency": 0.28},
 "antenna": {"frequencyHz": 8.4e9, "txPowerW": 10}, "rfThresholdDb": 3}
```

Omettete `antenna` per disattivare l'RF. Un parametro scritto male dà errore 422 (non viene ignorato).

## Come leggere i risultati

Tre condizioni **distinte**, mai fuse: `sunlit` (disco solare sopra l'orizzonte), `earth_visible` (disco terrestre
sopra l'orizzonte), `rf_ok` (margine ≥ soglia). Per l'RF, `path_condition` separa: `los_clear`,
`fresnel_zone_obstructed`, `diffracted`, `shadowed_beyond_model`. Una finestra RF può includere tratti in cui il
link regge **solo per diffrazione**: guardate `rf_relying_on_diffraction_percent`, non è una garanzia.
Ogni finestra riporta il motivo di chiusura (`terrain_occultation`, `below_lunar_horizon`,
`margin_below_threshold`, …). Il pannello solare di default è verticale e segue l'azimut del Sole
(con il Sole a pochi gradi un pannello inclinato di 15° produrrebbe quasi nulla).

## Dati reali LOLA: usate gli script

```bash
python scripts/prepare_lola_dem.py LDEM_85S_20M.JP2 -o data/dem/LDEM_85S_20M_sito.tif --crop LAT LON 90
python scripts/check_dem.py data/dem/LDEM_85S_20M_sito.tif --lat LAT --lon LON --range-km 60
```

Nei prodotti LOLA **altezza = DN × 0.5**; l'OFFSET 1737400 del label è solo per il raggio planetario e NON va
sommato (con `gdal_translate -unscale` si può ottenere il raggio per errore: il lettore e `check_dem.py` lo segnalano).
`check_dem.py` controlla unità, proiezione (contro il CRS del file), distanza dal bordo, orizzonte e caratteristiche note.

## Dati Artemis

`data/artemis_regions.json` contiene le **17 regioni candidate** NASA: le 13 annunciate nel 2022 e le 9 raffinate nel
2024 (4 sono nuove: Peak near Cabeus B, Mons Mouton Plateau, Mons Mouton, Slater Plain), con i puntatori ai DEM a 5 m
(Barker et al., PGDA prodotto 78; Bertone et al., prodotto 104) e le note sullo stato del programma
(Artemis III è ora un test in orbita terrestre, il primo allunaggio è Artemis IV: chiamatele *Artemis landing candidate
regions*). **Le coordinate sono volutamente null**: nelle fonti consultate NASA non le pubblica per le singole regioni.

```bash
python scripts/add_artemis_site.py --list
python scripts/add_artemis_site.py --region malapert-massif --lat LAT --lon LON --source "Quickmap" --verified
python scripts/add_artemis_site.py --region haworth --from-dem data/dem/Haworth.tif --source "centro DEM PGDA"
```

`/artemis/regions` mostra per ogni regione `needs_coordinates` → `no_dem` → `ready`. Per il criterio NASA del 2022 (luce
continua per tutta la permanenza) usate `/stay-windows` (`stay_hours` 156 = 6,5 giorni dell'Artemis III originale: imposta
quella della missione). La risoluzione è `stepMinutes`: un'ombra più breve del passo può sfuggire, riducetelo per decidere.

## Cosa è stato verificato

* Punto sub-solare per 2027-04-07 00:00 UTC: **1.299° N, 174.615° E** (la vostra app mostra 1.30° N, 174.61° E).
* Librazione (±6.6° lat, ±6° lon su 30 giorni) e declinazione solare (≤1.55°) entro i limiti noti; al polo il Sole
  resta sotto ~1.8°.
* Orizzonte confrontato con la formula chiusa (muro alto 500 m a 10 km); orizzonte su sfera nuda = −acos(R/(R+h)).
* FSPL Terra–Luna a 8.4 GHz ≈ 222.6 dB; margine confrontato con il calcolo a mano; J(ν) di P.526.
* Fallback analitico vs SPICE: < 0.02° (direzioni Sole/Terra).

## Cosa NON è stato verificato / non c'è

* Il frame `MOON_ME_DE440_ME421` con i PCK NAIF: nel test ho potuto usare solo `de440.bsp` + rotazione IAU 2009
  (kernel lunari non raggiungibili dalla sandbox). Provatelo sulla vostra macchina e confrontate con Horizons.
* Nessun DEM LOLA reale è stato letto (la sandbox non raggiunge i server NASA): i test usano file sintetici con le
  stesse caratteristiche (int16, scala 0.5, offset 1737400, stereografica polare sud). La convenzione di proiezione
  coincide con quella di PROJ; provate `check_dem.py` su un file vero.
* Nessuna validazione contro Horizons/Quickmap, né dati di volo. I parametri RF sono illustrativi.
* Non incluso: multipath (two-ray), cresta arrotondata (GPR), relay/LunaNet, ombre portate del lander,
  limb darkening, bilancio energetico con batteria. Diffrazione: knife-edge singolo, oltre ν = 2.4 il link è
  dichiarato `unavailable` (soglia euristica in `config.py`).
* Orizzonte: campionamento uniforme alla risoluzione del DEM fino a `horizonRangeKm` (default 60 km); oltre il
  bordo del DEM il terreno è trattato come sfera (segnalato).
