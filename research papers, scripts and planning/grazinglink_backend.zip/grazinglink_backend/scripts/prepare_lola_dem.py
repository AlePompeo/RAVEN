"""Converte un DEM LOLA (IMG+LBL, JP2 o GeoTIFF) in un GeoTIFF Float32 con la quota in METRI,
con ritaglio opzionale attorno a un sito (consigliato: i file interi pesano da 0.1 a 1.8 GB).

Regola dei prodotti LOLA GDR (PDS):   ALTEZZA [m] = DN * SCALING_FACTOR      (SCALING_FACTOR = 0.5)
                                      RAGGIO  [m] = DN * SCALING_FACTOR + OFFSET   (OFFSET = 1737400)
L'OFFSET del label serve solo per il raggio planetario: qui NON viene sommato.

Uso:
  python scripts/prepare_lola_dem.py LDEM_85S_20M.JP2 -o data/dem/LDEM_85S_20M_malapert.tif \
         --crop -85.98 -1.67 90          # lat lon raggio_km attorno al sito
  python scripts/prepare_lola_dem.py LDEM_85S_40M.LBL -o data/dem/LDEM_85S_40M.tif          # tutto il tile
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from grazinglink.terrain import latlon_to_xy_south  # noqa: E402

LUNAR_SPHERE = "+proj=longlat +a=1737400 +b=1737400 +no_defs"
BLOCK = 1024


def site_xy(ds, lat: float, lon: float) -> tuple[float, float]:
    """Coordinate del sito nel sistema del FILE (se ha un CRS), altrimenti nella convenzione LOLA."""
    if ds.crs:
        from rasterio.warp import transform
        xs, ys = transform(LUNAR_SPHERE, ds.crs, [lon], [lat])
        return float(xs[0]), float(ys[0])
    print("  ATTENZIONE: il file non ha un CRS, uso la convenzione polare sud LOLA (da verificare).")
    x, y = latlon_to_xy_south(lat, lon)
    return float(x), float(y)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--scale", type=float, default=None, help="fattore DN->metri (default: quello del file; LOLA = 0.5)")
    ap.add_argument("--crop", nargs=3, type=float, metavar=("LAT", "LON", "RAGGIO_KM"))
    a = ap.parse_args()

    import rasterio
    from rasterio.windows import Window

    with rasterio.open(a.input) as ds:
        scale = a.scale if a.scale is not None else float(ds.scales[0])
        file_offset = float(ds.offsets[0])
        res = abs(ds.transform.a)
        print(f"Input: {ds.width}x{ds.height} px, {res:g} m/px, dtype {ds.dtypes[0]}, "
              f"scala del file {ds.scales[0]:g}, offset del file {file_offset:g}")
        if ds.dtypes[0].startswith("int") and scale == 1.0:
            print("  ATTENZIONE: scala 1.0 su dati interi. Per gli LDEM LOLA il fattore e' 0.5: usa --scale 0.5.")
        if file_offset:
            print(f"  Nota: l'offset {file_offset:g} e' il raggio di riferimento: NON viene sommato (altezza = DN*scala).")

        if a.crop:
            lat, lon, rkm = a.crop
            x, y = site_xy(ds, lat, lon)
            r_c, c_c = ds.index(x, y)
            half = int(np.ceil(rkm * 1000.0 / res))
            r0, r1 = max(0, r_c - half), min(ds.height, r_c + half + 1)
            c0, c1 = max(0, c_c - half), min(ds.width, c_c + half + 1)
            if r0 >= r1 or c0 >= c1:
                print(f"ERRORE: il sito ({lat}, {lon}) non cade nel file.")
                return 1
        else:
            r0, r1, c0, c1 = 0, ds.height, 0, ds.width
        win = Window(c0, r0, c1 - c0, r1 - r0)

        # controllo sulle quote prima di scrivere (lettura decimata)
        small = ds.read(1, window=win, out_shape=(min(win.height, 800), min(win.width, 800))).astype(np.float64)
        if ds.nodata is not None:
            small[small == ds.nodata] = np.nan
        h = small * scale
        med, lo, hi = np.nanmedian(np.abs(h)), np.nanmin(h), np.nanmax(h)
        print(f"Quote nella finestra: min {lo:.0f} m, max {hi:.0f} m, mediana |z| {med:.0f} m")
        if med > 50_000:
            print("ERRORE: quote implausibili (sembrano raggi). Controlla --scale e l'offset.")
            return 1
        if hi - lo > 30_000:
            print("ATTENZIONE: dislivello > 30 km, insolito per il polo sud lunare: controlla la scala.")

        prof = dict(driver="GTiff", dtype="float32", count=1, width=win.width, height=win.height,
                    transform=ds.window_transform(win), crs=ds.crs, nodata=np.nan,
                    tiled=True, blockxsize=256, blockysize=256, compress="deflate", predictor=3)
        out = Path(a.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(out, "w", **prof) as dst:
            for r in range(0, win.height, BLOCK):
                h_blk = min(BLOCK, win.height - r)
                w_blk = Window(c0, r0 + r, win.width, h_blk)
                raw = ds.read(1, window=w_blk)
                arr = raw.astype(np.float32) * np.float32(scale)
                if ds.nodata is not None:
                    arr[raw == ds.nodata] = np.nan
                dst.write(arr, 1, window=Window(0, r, win.width, h_blk))
    print(f"Scritto {out}  ({win.width}x{win.height} px, altezza in metri sulla sfera di 1737.4 km)")
    print("Prossimo passo: python scripts/check_dem.py", out, "--lat LAT --lon LON")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
