"""Diagnostica di un DEM prima di usarlo nel backend.

Uso:  python scripts/check_dem.py data/dem/LDEM_85S_20M_malapert.tif --lat -85.98 --lon -1.67 [--range-km 60]

Controlla, con PASS / WARN / FAIL:
  1. unita': le quote sono altezze (non raggi planetari) e di ordine di grandezza lunare;
  2. proiezione: il CRS del FILE coincide con la convenzione assunta dal backend (stereografica polare sud);
  3. copertura: il sito sta dentro il DEM, abbastanza lontano dal bordo rispetto al raggio dell'orizzonte;
  4. sito e orizzonte: quota del sito, orizzonte massimo e minimo, azimut coperti da dati mancanti;
  5. caratteristiche: lat/lon del punto piu' alto e piu' basso vicino al sito, da confrontare con Quickmap/Moon Trek.
Esce con codice 1 se c'e' almeno un FAIL.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from grazinglink.horizon import HorizonEngine  # noqa: E402
from grazinglink.terrain import GeoTiffDemSource, latlon_to_xy_south, xy_to_latlon_south  # noqa: E402

LUNAR_SPHERE = "+proj=longlat +a=1737400 +b=1737400 +no_defs"
failures = 0


def report(level: str, msg: str) -> None:
    global failures
    failures += level == "FAIL"
    print(f"[{level}] {msg}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dem")
    ap.add_argument("--lat", type=float, required=True)
    ap.add_argument("--lon", type=float, required=True)
    ap.add_argument("--range-km", type=float, default=60.0)
    ap.add_argument("--height", type=float, default=2.0, help="altezza dell'osservatore (m)")
    a = ap.parse_args()

    import rasterio
    ds = rasterio.open(a.dem)
    print(f"File: {a.dem}\n  {ds.width}x{ds.height} px, {abs(ds.transform.a):g} m/px, dtype {ds.dtypes[0]}, "
          f"nodata {ds.nodata}, CRS {'presente' if ds.crs else 'ASSENTE'}")
    if ds.transform.e >= 0:
        report("FAIL", "asse y crescente (raster 'south-up'): non supportato")
        return 1

    # 1) unita'
    small = ds.read(1, out_shape=(min(ds.height, 800), min(ds.width, 800))).astype(np.float64)
    if ds.nodata is not None and not np.isnan(ds.nodata):
        small[small == ds.nodata] = np.nan
    lo, hi, med = np.nanmin(small), np.nanmax(small), np.nanmedian(np.abs(small))
    print(f"  quote (campione): min {lo:.0f} m, max {hi:.0f} m, mediana |z| {med:.0f} m")
    if med > 50_000:
        report("FAIL", "le quote sembrano il RAGGIO planetario (DN*0.5+1737400), non l'altezza: usa prepare_lola_dem.py")
    elif hi - lo > 30_000:
        report("WARN", "dislivello > 30 km: insolito per il polo sud lunare, controlla la scala")
    elif ds.dtypes[0].startswith("int") and (ds.scales[0] == 1.0) and (hi - lo) > 0 and (hi - lo) < 400:
        report("WARN", "dati interi con scala 1.0 e dislivello minuscolo: forse manca il fattore 0.5 dei DN LOLA")
    else:
        report("PASS", "ordine di grandezza delle quote compatibile con altezze lunari")

    # 2) proiezione
    probe = [(a.lat, a.lon), (-88.0, 30.0), (-85.5, -120.0)]
    if ds.crs:
        from rasterio.warp import transform
        try:
            xs, ys = transform(LUNAR_SPHERE, ds.crs, [p[1] for p in probe], [p[0] for p in probe])
            ax, ay = latlon_to_xy_south(np.array([p[0] for p in probe]), np.array([p[1] for p in probe]))
            err = float(np.max(np.hypot(np.array(xs) - ax, np.array(ys) - ay)))
            if err < 1.0:
                report("PASS", f"proiezione del file = convenzione del backend (scarto max {err:.3f} m)")
            else:
                report("FAIL", f"proiezione diversa dalla convenzione del backend (scarto {err:.0f} m): "
                               "il DEM verrebbe campionato nel punto sbagliato. Rilevante: x=rho*sin(lon), y=rho*cos(lon)")
        except Exception as exc:  # CRS non convertibile da PROJ
            report("WARN", f"impossibile confrontare il CRS del file ({exc}): verifica a mano con il punto 5")
    else:
        report("WARN", "file senza CRS: la convenzione LOLA e' solo assunta. Fai molta attenzione al punto 5")

    # 3) copertura
    src = GeoTiffDemSource(a.dem)
    if not src.covers(a.lat, a.lon):
        report("FAIL", f"il sito ({a.lat}, {a.lon}) e' fuori dal DEM")
        return 1
    x, y = latlon_to_xy_south(a.lat, a.lon)
    left, bottom, right, top = ds.bounds
    edge_km = min(x - left, right - x, y - bottom, top - y) / 1000.0
    if edge_km < a.range_km:
        report("WARN", f"il bordo del DEM dista {edge_km:.0f} km dal sito, meno del raggio dell'orizzonte "
                       f"({a.range_km:g} km): usa un tile piu' grande o riduci horizonRangeKm")
    else:
        report("PASS", f"il bordo del DEM dista {edge_km:.0f} km dal sito (>= {a.range_km:g} km)")

    # 4) sito e orizzonte
    dem = src.load(a.lat, a.lon, a.range_km * 1000.0)
    eng = HorizonEngine()
    z_site = eng.site_elevation(dem, a.lat, a.lon)
    prof = eng.profile(dem, a.lat, a.lon, a.height, 360, a.range_km * 1000.0)
    k = int(np.argmax(prof.elev_deg))
    print(f"  quota del sito: {z_site:.1f} m sulla sfera di 1737.4 km")
    print(f"  orizzonte: max {prof.elev_deg.max():.2f} deg verso azimut {prof.az_deg[k]:.0f} "
          f"(a {prof.range_m[k] / 1000:.1f} km), min {prof.elev_deg.min():.2f} deg, "
          f"dato mancante lungo il {100 * prof.dem_limited.mean():.0f}% degli azimut")
    if not np.isfinite(z_site) or np.isnan(dem.sample(np.array([x]), np.array([y]))[0]):
        report("FAIL", "nessun dato di quota al sito")
    elif prof.dem_limited.mean() > 0.05:
        report("WARN", "molti azimut incontrano celle senza dato o il bordo del DEM: orizzonte ottimistico")
    else:
        report("PASS", "orizzonte calcolato su dati completi")

    # 5) caratteristiche note
    half = min(20_000.0, a.range_km * 1000.0)
    n = int(2 * half / dem.res_m) + 1
    gx = np.linspace(x - half, x + half, min(n, 801))
    gy = np.linspace(y - half, y + half, min(n, 801))
    xx, yy = np.meshgrid(gx, gy)
    z = dem.sample(xx, yy)
    if np.isfinite(z).any():
        for label, idx in (("piu' alto", np.nanargmax(z)), ("piu' basso", np.nanargmin(z))):
            r, c = np.unravel_index(idx, z.shape)
            la, lo_ = xy_to_latlon_south(xx[r, c], yy[r, c])
            print(f"  punto {label} entro {half / 1000:.0f} km: lat {float(la):.3f}, lon {float(lo_):.3f}, quota {z[r, c]:.0f} m")
        print("  -> confronta queste coordinate con una caratteristica nota (Quickmap / Moon Trek): se la "
              "cima o il cratere sono altrove, orientamento o proiezione sono sbagliati.")
    print(f"\n{'ESITO: FAIL' if failures else 'ESITO: nessun FAIL (leggi comunque i WARN)'}")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
