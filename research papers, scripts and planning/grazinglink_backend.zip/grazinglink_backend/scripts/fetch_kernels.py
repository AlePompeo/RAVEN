"""Scarica i kernel SPICE minimi da NAIF in ./kernels (servono ~ 40 MB con de440s).

Uso:  python scripts/fetch_kernels.py
Se un URL non risponde, controlla le directory su https://naif.jpl.nasa.gov/pub/naif/generic_kernels/
(i nomi dei file con data possono cambiare: aggiorna la lista qui sotto).
"""
from pathlib import Path
from urllib.request import urlretrieve

BASE = "https://naif.jpl.nasa.gov/pub/naif/generic_kernels/"
FILES = [
    "lsk/naif0012.tls",                          # leap seconds
    "spk/planets/de440s.bsp",                    # effemeridi Sole/Terra/Luna
    "pck/moon_pa_de440_200625.bpc",              # orientamento lunare ad alta precisione
    "fk/satellites/moon_de440_250416.tf",        # frame MOON_ME_DE440_ME421 / MOON_PA_DE440
]

dest = Path(__file__).resolve().parent.parent / "kernels"
dest.mkdir(exist_ok=True)
for rel in FILES:
    target = dest / Path(rel).name
    if target.exists():
        print("gia' presente:", target.name)
        continue
    print("scarico", rel)
    urlretrieve(BASE + rel, target)
print("fatto ->", dest)
