"""Imposta le coordinate di una regione Artemis nel catalogo (data/artemis_regions.json).

Nelle fonti NASA consultate non ci sono coordinate per i singoli siti: prendile da una fonte ufficiale o
verificata (Quickmap/Moon Trek, pubblicazioni NASA) e indicala con --source.

Uso:
  python scripts/add_artemis_site.py --list
  python scripts/add_artemis_site.py --region malapert-massif --lat LAT --lon LON --source "Quickmap, punto scelto" --verified
  python scripts/add_artemis_site.py --region haworth --from-dem data/dem/Haworth.tif --source "centro del DEM PGDA"

Con --from-dem si usa il CENTRO del DEM: e' un punto di partenza, non il sito di atterraggio. Controlla
la posizione con scripts/check_dem.py e ricorda che le regioni NASA sono di circa 15 x 15 km.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from grazinglink.artemis import dem_center_latlon, load_artemis, set_region_coordinates  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true", help="elenca le regioni e lo stato delle coordinate")
    ap.add_argument("--region")
    ap.add_argument("--lat", type=float)
    ap.add_argument("--lon", type=float)
    ap.add_argument("--from-dem", help="usa il centro di questo GeoTIFF polare sud")
    ap.add_argument("--source", default="")
    ap.add_argument("--verified", action="store_true", help="segna le coordinate come verificate su fonte ufficiale")
    a = ap.parse_args()

    if a.list or not a.region:
        for r in load_artemis()["regions"]:
            lists = ("2022" if r["in_2022_list_of_13"] else "") + ("+2024" if r["in_2024_list_of_9"] else "")
            where = f"{r['latitude']}, {r['longitude']}" if r["latitude"] is not None else "coordinate mancanti"
            print(f"{r['id']:28s} lista {lists.strip('+'):9s} {where}")
        return 0

    if a.from_dem:
        lat, lon = dem_center_latlon(a.from_dem)
        print(f"Centro del DEM: lat {lat:.4f}, lon {lon:.4f}  (da verificare: non e' per forza il sito)")
    elif a.lat is not None and a.lon is not None:
        lat, lon = a.lat, a.lon
    else:
        print("ERRORE: indica --lat e --lon oppure --from-dem")
        return 1
    try:
        r = set_region_coordinates(a.region, lat, lon, a.source, a.verified)
    except (ValueError, KeyError) as exc:
        print("ERRORE:", exc)
        return 1
    print(f"Salvato {r['id']}: lat {r['latitude']}, lon {r['longitude']}, fonte '{r['coordinates_source']}', "
          f"verificate: {r['coordinates_verified']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
